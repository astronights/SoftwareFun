package com.example.projectlab3.boundary

import com.example.projectlab3.entity.Route

object Histface {
    fun getHist(){
        // This functions calls the database manager to display history of routes taken
    }

    fun saveFav(r: Route){
        //saves favorite routes
    }
}