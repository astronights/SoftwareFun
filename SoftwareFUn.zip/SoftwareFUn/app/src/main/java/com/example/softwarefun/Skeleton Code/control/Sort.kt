package com.example.projectlab3.control

import com.example.projectlab3.entity.Route

object Sort {
    fun sort(c: Boolean):Array<Route> {
        // if = 0 sort by price, =1 sort by time
    }
}