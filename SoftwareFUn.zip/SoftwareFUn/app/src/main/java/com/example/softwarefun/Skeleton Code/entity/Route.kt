package com.example.projectlab3.entity

class Route {
    var org: String=""
    var dest: String=""


}