package com.example.projectlab3.boundary

import com.example.projectlab3.entity.Route

object Favface {
    fun getfav(){
        // this functions call the DataBase Manager to display Favourites
    }
    fun delfav(r:Route){
        // this functions calls the DataBase Manager to delete a route from the Favourite list
    }
}