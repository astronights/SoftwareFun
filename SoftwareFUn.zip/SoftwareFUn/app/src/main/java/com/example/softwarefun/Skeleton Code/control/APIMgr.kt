package cz2006.control

import java.time.LocalDateTime

object APIMgr{
    fune
        //calls Google Maps API for directions
    }
    fun ltaBusArrival(bstopnum:Int, busnum:Int){
        //calls LTA Datamall to get bus arrival times at specific busstop
    }
    fun datagovBusFare(busnum:Int,startstopnum:Int,endstopnum:Int) : Double{
        //calls Data.gov API to get bus fare of specific bus from two busstops
        return 1.2
    }
}