package com.google.test5

import android.content.Context
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.BaseAdapter
import android.widget.ImageView
import android.widget.TextView
import javax.sql.DataSource
import kotlinx.android.synthetic.main.results.*

class DirectionAdapter(private val context: Context, private val dataSource:ArrayList<Routes>):BaseAdapter() {
    private val inflater: LayoutInflater
            = context.getSystemService(Context.LAYOUT_INFLATER_SERVICE) as LayoutInflater

    override fun getCount(): Int {
        return dataSource.size
    }
    override fun getItem(position: Int): Any {
        return dataSource[position]
    }
    override fun getItemId(position: Int): Long {
        return position.toLong()
    }
    override fun getView(position: Int, convertView: View?, parent: ViewGroup): View {
        // Get view for row item
        val rowView = inflater.inflate(R.layout.results, parent, false)

        // Get title element
        val titleTextView = rowView.findViewById(R.id.recipe_list_title) as TextView
// Get detail element
        val detailTextView = rowView.findViewById(R.id.recipe_list_detail) as TextView
        val subtitleTextView = rowView.findViewById(R.id.text1) as TextView
        val routes = getItem(position) as Routes

// 2
        var title : String=""
        var subtitle : String =""
        var detail: String = ""
        var totaldistance: Double = 0.0
        for (i in 0..routes.legs[0].steps.size-1){
            if (routes.legs[0].steps[i].transit_details.line.vehicle.name == "Bus"){
                title += routes.legs[0].steps[i].transit_details.line.vehicle.name+" "+routes.legs[0].steps[i].transit_details.line.short_name+"->"
            }else if (routes.legs[0].steps[i].transit_details.line.vehicle.name == "Subway"){
                title += routes.legs[0].steps[i].transit_details.line.name+"->"
            }
        }
        for (i in 0..routes.legs[0].steps.size-1){
            if (routes.legs[0].steps[i].transit_details.line.vehicle.name == "Bus"){
                subtitle += routes.legs[0].steps[i].transit_details.departure_stop.name+"-"+routes.legs[0].steps[i].transit_details.arrival_stop.name+"->"
            }else if (routes.legs[0].steps[i].transit_details.line.vehicle.name == "Subway"){
                subtitle += routes.legs[0].steps[i].transit_details.departure_stop.name+" Station-"+routes.legs[0].steps[i].transit_details.arrival_stop.name+" Station->"
            }
        }


        titleTextView.text = title.substring(0,title.length-2)
        detailTextView.text = routes.legs[0].duration.text
        subtitleTextView.text = subtitle.substring(0,subtitle.length-2)

        return rowView
    }
}