package com.google.test5

import android.content.ClipData
import android.content.Context
import android.content.Intent
import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import android.support.design.widget.BottomNavigationView
import android.support.v7.widget.LinearLayoutManager
import android.support.v7.widget.OrientationHelper
import android.util.Log
import android.view.View
import android.widget.AdapterView
import android.widget.ArrayAdapter
import android.widget.ListView
import android.widget.Toast
import com.google.gson.Gson
import kotlinx.android.synthetic.main.activity_direction.*
import kotlinx.android.synthetic.main.results.*

var id1 = 0

class DirectionActivity : AppCompatActivity() {
    var r = ArrayList<String>()
    var allRoute= ArrayList<Routes>()
    var a: Int = -1
    private val HISTORY = "history"

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_direction)

        val origin = intent.getStringExtra("origin")
        val destination = intent.getStringExtra("destination")
        val mode = intent.getIntExtra("mode", 0)
        allRoute = Direction(getDirectionURL(origin, destination, mode)).getResp()
        RouteSave.routes = allRoute
        Log.d("Dog","Size of allRoute is "+allRoute.size.toString())
        lateinit var listView: ListView
        //val adapter = ArrayAdapter(this, R.layout.results, r)
        //listView = findViewById(R.id.listView_1) as ListView
        //listView.adapter = adapter
        listView=findViewById<ListView>(R.id.listView_1)

        val adapter=DirectionAdapter(this, allRoute)
        listView.adapter=adapter
        //pictures.layoutManager = LinearLayoutManager(this, OrientationHelper.HORIZONTAL,false)
        //pictures.adapter = PictureAdapter(this,RouteSave.routes)

        listView.onItemClickListener = object : AdapterView.OnItemClickListener{
            override fun onItemClick(parent: AdapterView<*>?, view: View?, position: Int, id: Long) {
                val intent1 = Intent(this@DirectionActivity, MapsActivity::class.java).apply {
                    putExtra("position", position)
                }
                RouteSave.pos = position
                // First initialize a list of UserInfoDTO.
                val initialUserInfoList: Routes = allRoute[position]

                // Create Gson object.
                val gson = Gson()

                // Get java object list json format string.
                val userInfoListJsonString = gson.toJson(initialUserInfoList)
                // Create SharedPreferences object.
                val ctx = applicationContext
                val sharedPreferences =
                    ctx.getSharedPreferences(HISTORY, Context.MODE_PRIVATE)
                // Put the json format string to SharedPreferences object.
                val editor = sharedPreferences.edit()

                editor.putString(id.toString(), userInfoListJsonString)
                id1+=1
//            Toast.makeText(ctx, userInfoListJsonString, Toast.LENGTH_SHORT)
//                .show()
                editor.apply()
                //Popup a toast message in screen bottom.
                Toast.makeText(ctx, id.toString() + " Route has been Saved to storage", Toast.LENGTH_SHORT)
                    .show()
                startActivity(intent1)
            }
        }


    }







    fun getDirectionURL(origin: String, dest: String, mode: Int): String {
        if (mode == 0) {
            return "https://maps.googleapis.com/maps/api/directions/json?origin=${origin}&destination=${dest}&mode=transit&transit_mode=bus|subway&alternatives=true&key=AIzaSyCkuHNW1JRQY9o-zLyCg65EuOws1vIP-RE"
        } else if (mode == 1) {
            return "https://maps.googleapis.com/maps/api/directions/json?origin=${origin}&destination=${dest}&mode=transit&transit_mode=bus&alternatives=true&key=AIzaSyCkuHNW1JRQY9o-zLyCg65EuOws1vIP-RE"
        } else if (mode == 2) {
            return "https://maps.googleapis.com/maps/api/directions/json?origin=${origin}&destination=${dest}&mode=transit&transit_mode=subway&alternatives=true&key=AIzaSyCkuHNW1JRQY9o-zLyCg65EuOws1vIP-RE"
        }
        return "error"
    }
    private val mOnNavigationItemSelectedListener = BottomNavigationView.OnNavigationItemSelectedListener { item ->
        when (item.itemId) {
            R.id.navigation_search -> {
                val intent1=Intent(this,MainActivity::class.java).apply(){}
                startActivity(intent1)

                return@OnNavigationItemSelectedListener true
            }
            R.id.navigation_current -> {
                val intent1= Intent(this,MapsActivity::class.java).apply(){}
                startActivity(intent1)
                return@OnNavigationItemSelectedListener true
            }
            R.id.navigation_hist -> {
                val intent1 = Intent(this, activity_hist::class.java).apply(){}
                startActivity(intent1)
                return@OnNavigationItemSelectedListener true
            }
            R.id.navigation_fav -> {

                return@OnNavigationItemSelectedListener true
            }
        }
        false
    }
}


