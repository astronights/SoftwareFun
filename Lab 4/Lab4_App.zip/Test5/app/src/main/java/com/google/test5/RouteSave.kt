package com.google.test5

object RouteSave {
    var routes = ArrayList<Routes>()
    var pos : Int =0
}