package com.google.test5

import android.util.Log
import com.google.gson.Gson
import okhttp3.OkHttpClient
import okhttp3.Request

object Fare{
    var url = "https://data.gov.sg/api/action/datastore_search?resource_id=e1c20915-ab7c-4bf9-bbbd-0197bbc7b98cf"

    fun getFare(distance:Double,status:String):Int {
        val client = OkHttpClient()
        val request = Request.Builder().url(url).build()
        val response = client.newCall(request).execute()
        val data = response.body()!!.string()
        var result = 0
        val respObj = Gson().fromJson(data,FareDTO::class.java)
        Log.d("Price","Distance is "+respObj.result.records[1].distance)
        Log.d("Price","Adult card fare is "+respObj.result.records[1].adult_card_fare_per_ride)
        Log.d("Price","Adult cash fare is "+respObj.result.records[1].adult_cash_fare_per_ride)
        Log.d("Price","Student Card Fare is "+respObj.result.records[1].student_card_fare_per_ride)
        Log.d("Price","Student Cash Fare is "+respObj.result.records[1].student_cash_fare_per_ride)
        Log.d("Price","Senior Citizen Card Fare is "+respObj.result.records[1].senior_citizen_card_fare_per_ride)
        Log.d("Price","Senior Citizen Cash Fare is "+respObj.result.records[1].senior_citizen_cash_fare_per_ride)
        Log.d("Price","Id is "+respObj.result.records[1]._id)
            if (distance<3.2) {
                for (i in 0..respObj.result.records.size - 1) {
                    if (respObj.result.records[i].distance == "Up to 3.2 km") {
                        if (status == "senior_citizen_card_fare_per_ride") {
                            result = respObj.result.records[i].senior_citizen_card_fare_per_ride.toInt()
                        } else if (status == "student_card_fare_per_ride") {
                            result = respObj.result.records[i].student_card_fare_per_ride.toInt()
                        } else if (status == "workfare_transport_concession_cash_fare_per_ride") {
                            result = respObj.result.records[i].workfare_transport_concession_cash_fare_per_ride.toInt()
                        } else if (status == "persons_with_disabilities_card_fare_per_ride") {
                            result = respObj.result.records[i].persons_with_disabilities_card_fare_per_ride.toInt()
                        } else if (status == "adult_card_fare_per_ride") {
                            result = respObj.result.records[i].adult_card_fare_per_ride.toInt()
                        } else if (status == "senior_citizen_cash_fare_per_ride") {
                            result = respObj.result.records[i].senior_citizen_cash_fare_per_ride.toInt()
                        } else if (status == "persons_with_disabilities_cash_fare_per_ride") {
                            result = respObj.result.records[i].persons_with_disabilities_cash_fare_per_ride.toInt()
                        } else if (status == "workfare_transport_concessions_card_fare_per_ride") {
                            result = respObj.result.records[i].workfare_transport_concession_cash_fare_per_ride.toInt()
                        } else if (status == "adult_cash_fare_per_ride") {
                            result = respObj.result.records[i].adult_cash_fare_per_ride.toInt()
                        } else if (status == "student_cash_fare_per_ride") {
                            result = respObj.result.records[i].student_cash_fare_per_ride.toInt()
                        }
                    }
                }
            } else if (distance < 4.2){
                for (i in 0..respObj.result.records.size - 1) {
                    if (respObj.result.records[i].distance == "3.3 km - 4.2 km") {
                        if (status == "senior_citizen_card_fare_per_ride") {
                            result =  respObj.result.records[i].senior_citizen_card_fare_per_ride.toInt()
                        } else if (status == "student_card_fare_per_ride") {
                            result =  respObj.result.records[i].student_card_fare_per_ride.toInt()
                        } else if (status == "workfare_transport_concession_cash_fare_per_ride") {
                            result =  respObj.result.records[i].workfare_transport_concession_cash_fare_per_ride.toInt()
                        } else if (status == "persons_with_disabilities_card_fare_per_ride") {
                            result =  respObj.result.records[i].persons_with_disabilities_card_fare_per_ride.toInt()
                        } else if (status == "adult_card_fare_per_ride") {
                            result =  respObj.result.records[i].adult_card_fare_per_ride.toInt()
                        } else if (status == "senior_citizen_cash_fare_per_ride") {
                            result =  respObj.result.records[i].senior_citizen_cash_fare_per_ride.toInt()
                        } else if (status == "persons_with_disabilities_cash_fare_per_ride") {
                            result =  respObj.result.records[i].persons_with_disabilities_cash_fare_per_ride.toInt()
                        } else if (status == "workfare_transport_concessions_card_fare_per_ride") {
                            result =  respObj.result.records[i].workfare_transport_concession_cash_fare_per_ride.toInt()
                        } else if (status == "adult_cash_fare_per_ride") {
                            result =  respObj.result.records[i].adult_cash_fare_per_ride.toInt()
                        } else if (status == "student_cash_fare_per_ride") {
                            result =  respObj.result.records[i].student_cash_fare_per_ride.toInt()
                        }
                    }
                }
            } else if (distance <5.2){
                for (i in 0..respObj.result.records.size - 1) {
                    if (respObj.result.records[i].distance == "4.3 km - 5.2 km") {
                        if (status == "senior_citizen_card_fare_per_ride") {
                            result =  respObj.result.records[i].senior_citizen_card_fare_per_ride.toInt()
                        } else if (status == "student_card_fare_per_ride") {
                            result =  respObj.result.records[i].student_card_fare_per_ride.toInt()
                        } else if (status == "workfare_transport_concession_cash_fare_per_ride") {
                            result =  respObj.result.records[i].workfare_transport_concession_cash_fare_per_ride.toInt()
                        } else if (status == "persons_with_disabilities_card_fare_per_ride") {
                            result =  respObj.result.records[i].persons_with_disabilities_card_fare_per_ride.toInt()
                        } else if (status == "adult_card_fare_per_ride") {
                            result =  respObj.result.records[i].adult_card_fare_per_ride.toInt()
                        } else if (status == "senior_citizen_cash_fare_per_ride") {
                            result =  respObj.result.records[i].senior_citizen_cash_fare_per_ride.toInt()
                        } else if (status == "persons_with_disabilities_cash_fare_per_ride") {
                            result =  respObj.result.records[i].persons_with_disabilities_cash_fare_per_ride.toInt()
                        } else if (status == "workfare_transport_concessions_card_fare_per_ride") {
                            result =  respObj.result.records[i].workfare_transport_concession_cash_fare_per_ride.toInt()
                        } else if (status == "adult_cash_fare_per_ride") {
                            result =  respObj.result.records[i].adult_cash_fare_per_ride.toInt()
                        } else if (status == "student_cash_fare_per_ride") {
                            result =  respObj.result.records[i].student_cash_fare_per_ride.toInt()
                        }
                    }
                }
            } else if (distance <6.2){
                for (i in 0..respObj.result.records.size - 1) {
                    if (respObj.result.records[i].distance == "5.3 km - 6.2 km") {
                        if (status == "senior_citizen_card_fare_per_ride") {
                            result =  respObj.result.records[i].senior_citizen_card_fare_per_ride.toInt()
                        } else if (status == "student_card_fare_per_ride") {
                            result =  respObj.result.records[i].student_card_fare_per_ride.toInt()
                        } else if (status == "workfare_transport_concession_cash_fare_per_ride") {
                            result =  respObj.result.records[i].workfare_transport_concession_cash_fare_per_ride.toInt()
                        } else if (status == "persons_with_disabilities_card_fare_per_ride") {
                            result =  respObj.result.records[i].persons_with_disabilities_card_fare_per_ride.toInt()
                        } else if (status == "adult_card_fare_per_ride") {
                            result =  respObj.result.records[i].adult_card_fare_per_ride.toInt()
                        } else if (status == "senior_citizen_cash_fare_per_ride") {
                            result =  respObj.result.records[i].senior_citizen_cash_fare_per_ride.toInt()
                        } else if (status == "persons_with_disabilities_cash_fare_per_ride") {
                            result =  respObj.result.records[i].persons_with_disabilities_cash_fare_per_ride.toInt()
                        } else if (status == "workfare_transport_concessions_card_fare_per_ride") {
                            result =  respObj.result.records[i].workfare_transport_concession_cash_fare_per_ride.toInt()
                        } else if (status == "adult_cash_fare_per_ride") {
                            result =  respObj.result.records[i].adult_cash_fare_per_ride.toInt()
                        } else if (status == "student_cash_fare_per_ride") {
                            result =  respObj.result.records[i].student_cash_fare_per_ride.toInt()
                        }
                    }
                }
            } else if (distance <7.2){
                for (i in 0..respObj.result.records.size - 1) {
                    if (respObj.result.records[i].distance == "6.3 km - 7.2 km") {
                        if (status == "senior_citizen_card_fare_per_ride") {
                            result =  respObj.result.records[i].senior_citizen_card_fare_per_ride.toInt()
                        } else if (status == "student_card_fare_per_ride") {
                            result =  respObj.result.records[i].student_card_fare_per_ride.toInt()
                        } else if (status == "workfare_transport_concession_cash_fare_per_ride") {
                            result =  respObj.result.records[i].workfare_transport_concession_cash_fare_per_ride.toInt()
                        } else if (status == "persons_with_disabilities_card_fare_per_ride") {
                            result =  respObj.result.records[i].persons_with_disabilities_card_fare_per_ride.toInt()
                        } else if (status == "adult_card_fare_per_ride") {
                            result =  respObj.result.records[i].adult_card_fare_per_ride.toInt()
                        } else if (status == "senior_citizen_cash_fare_per_ride") {
                            result =  respObj.result.records[i].senior_citizen_cash_fare_per_ride.toInt()
                        } else if (status == "persons_with_disabilities_cash_fare_per_ride") {
                            result =  respObj.result.records[i].persons_with_disabilities_cash_fare_per_ride.toInt()
                        } else if (status == "workfare_transport_concessions_card_fare_per_ride") {
                            result =  respObj.result.records[i].workfare_transport_concession_cash_fare_per_ride.toInt()
                        } else if (status == "adult_cash_fare_per_ride") {
                            result =  respObj.result.records[i].adult_cash_fare_per_ride.toInt()
                        } else if (status == "student_cash_fare_per_ride") {
                            result =  respObj.result.records[i].student_cash_fare_per_ride.toInt()
                        }
                    }
                }
            } else if (distance <8.2){
                for (i in 0..respObj.result.records.size - 1) {
                    if (respObj.result.records[i].distance == "7.3 km - 8.2 km") {
                        if (status == "senior_citizen_card_fare_per_ride") {
                            result =  respObj.result.records[i].senior_citizen_card_fare_per_ride.toInt()
                        } else if (status == "student_card_fare_per_ride") {
                            result =  respObj.result.records[i].student_card_fare_per_ride.toInt()
                        } else if (status == "workfare_transport_concession_cash_fare_per_ride") {
                            result =  respObj.result.records[i].workfare_transport_concession_cash_fare_per_ride.toInt()
                        } else if (status == "persons_with_disabilities_card_fare_per_ride") {
                            result =  respObj.result.records[i].persons_with_disabilities_card_fare_per_ride.toInt()
                        } else if (status == "adult_card_fare_per_ride") {
                            result =  respObj.result.records[i].adult_card_fare_per_ride.toInt()
                        } else if (status == "senior_citizen_cash_fare_per_ride") {
                            result =  respObj.result.records[i].senior_citizen_cash_fare_per_ride.toInt()
                        } else if (status == "persons_with_disabilities_cash_fare_per_ride") {
                            result =  respObj.result.records[i].persons_with_disabilities_cash_fare_per_ride.toInt()
                        } else if (status == "workfare_transport_concessions_card_fare_per_ride") {
                            result =  respObj.result.records[i].workfare_transport_concession_cash_fare_per_ride.toInt()
                        } else if (status == "adult_cash_fare_per_ride") {
                            result =  respObj.result.records[i].adult_cash_fare_per_ride.toInt()
                        } else if (status == "student_cash_fare_per_ride") {
                            result =  respObj.result.records[i].student_cash_fare_per_ride.toInt()
                        }
                    }
                }
            } else if (distance <9.2){
                for (i in 0..respObj.result.records.size - 1) {
                    if (respObj.result.records[i].distance == "8.3 km - 9.2 km") {
                        if (status == "senior_citizen_card_fare_per_ride") {
                            result =  respObj.result.records[i].senior_citizen_card_fare_per_ride.toInt()
                        } else if (status == "student_card_fare_per_ride") {
                            result =  respObj.result.records[i].student_card_fare_per_ride.toInt()
                        } else if (status == "workfare_transport_concession_cash_fare_per_ride") {
                            result =  respObj.result.records[i].workfare_transport_concession_cash_fare_per_ride.toInt()
                        } else if (status == "persons_with_disabilities_card_fare_per_ride") {
                            result =  respObj.result.records[i].persons_with_disabilities_card_fare_per_ride.toInt()
                        } else if (status == "adult_card_fare_per_ride") {
                            result =  respObj.result.records[i].adult_card_fare_per_ride.toInt()
                        } else if (status == "senior_citizen_cash_fare_per_ride") {
                            result =  respObj.result.records[i].senior_citizen_cash_fare_per_ride.toInt()
                        } else if (status == "persons_with_disabilities_cash_fare_per_ride") {
                            result =  respObj.result.records[i].persons_with_disabilities_cash_fare_per_ride.toInt()
                        } else if (status == "workfare_transport_concessions_card_fare_per_ride") {
                            result =  respObj.result.records[i].workfare_transport_concession_cash_fare_per_ride.toInt()
                        } else if (status == "adult_cash_fare_per_ride") {
                            result =  respObj.result.records[i].adult_cash_fare_per_ride.toInt()
                        } else if (status == "student_cash_fare_per_ride") {
                            result =  respObj.result.records[i].student_cash_fare_per_ride.toInt()
                        }
                    }
                }
            } else if (distance < 10.2){
                for (i in 0..respObj.result.records.size - 1) {
                    if (respObj.result.records[i].distance == "9.3 km - 10.2 km") {
                        if (status == "senior_citizen_card_fare_per_ride") {
                            result =  respObj.result.records[i].senior_citizen_card_fare_per_ride.toInt()
                        } else if (status == "student_card_fare_per_ride") {
                            result =  respObj.result.records[i].student_card_fare_per_ride.toInt()
                        } else if (status == "workfare_transport_concession_cash_fare_per_ride") {
                            result =  respObj.result.records[i].workfare_transport_concession_cash_fare_per_ride.toInt()
                        } else if (status == "persons_with_disabilities_card_fare_per_ride") {
                            result =  respObj.result.records[i].persons_with_disabilities_card_fare_per_ride.toInt()
                        } else if (status == "adult_card_fare_per_ride") {
                            result =  respObj.result.records[i].adult_card_fare_per_ride.toInt()
                        } else if (status == "senior_citizen_cash_fare_per_ride") {
                            result =  respObj.result.records[i].senior_citizen_cash_fare_per_ride.toInt()
                        } else if (status == "persons_with_disabilities_cash_fare_per_ride") {
                            result =  respObj.result.records[i].persons_with_disabilities_cash_fare_per_ride.toInt()
                        } else if (status == "workfare_transport_concessions_card_fare_per_ride") {
                            result =  respObj.result.records[i].workfare_transport_concession_cash_fare_per_ride.toInt()
                        } else if (status == "adult_cash_fare_per_ride") {
                            result =  respObj.result.records[i].adult_cash_fare_per_ride.toInt()
                        } else if (status == "student_cash_fare_per_ride") {
                            result =  respObj.result.records[i].student_cash_fare_per_ride.toInt()
                        }
                    }
                }
            } else if (distance <11.2){
                for (i in 0..respObj.result.records.size - 1) {
                    if (respObj.result.records[i].distance == "10.3 km - 11.2 km") {
                        if (status == "senior_citizen_card_fare_per_ride") {
                            result =  respObj.result.records[i].senior_citizen_card_fare_per_ride.toInt()
                        } else if (status == "student_card_fare_per_ride") {
                            result =  respObj.result.records[i].student_card_fare_per_ride.toInt()
                        } else if (status == "workfare_transport_concession_cash_fare_per_ride") {
                            result =  respObj.result.records[i].workfare_transport_concession_cash_fare_per_ride.toInt()
                        } else if (status == "persons_with_disabilities_card_fare_per_ride") {
                            result =  respObj.result.records[i].persons_with_disabilities_card_fare_per_ride.toInt()
                        } else if (status == "adult_card_fare_per_ride") {
                            result =  respObj.result.records[i].adult_card_fare_per_ride.toInt()
                        } else if (status == "senior_citizen_cash_fare_per_ride") {
                            result =  respObj.result.records[i].senior_citizen_cash_fare_per_ride.toInt()
                        } else if (status == "persons_with_disabilities_cash_fare_per_ride") {
                            result =  respObj.result.records[i].persons_with_disabilities_cash_fare_per_ride.toInt()
                        } else if (status == "workfare_transport_concessions_card_fare_per_ride") {
                            result =  respObj.result.records[i].workfare_transport_concession_cash_fare_per_ride.toInt()
                        } else if (status == "adult_cash_fare_per_ride") {
                            result =  respObj.result.records[i].adult_cash_fare_per_ride.toInt()
                        } else if (status == "student_cash_fare_per_ride") {
                            result =  respObj.result.records[i].student_cash_fare_per_ride.toInt()
                        }
                    }
                }
            } else if (distance <12.2){
                for (i in 0..respObj.result.records.size - 1) {
                    if (respObj.result.records[i].distance == "11.3 km - 12.2 km") {
                        if (status == "senior_citizen_card_fare_per_ride") {
                            result =  respObj.result.records[i].senior_citizen_card_fare_per_ride.toInt()
                        } else if (status == "student_card_fare_per_ride") {
                            result =  respObj.result.records[i].student_card_fare_per_ride.toInt()
                        } else if (status == "workfare_transport_concession_cash_fare_per_ride") {
                            result =  respObj.result.records[i].workfare_transport_concession_cash_fare_per_ride.toInt()
                        } else if (status == "persons_with_disabilities_card_fare_per_ride") {
                            result =  respObj.result.records[i].persons_with_disabilities_card_fare_per_ride.toInt()
                        } else if (status == "adult_card_fare_per_ride") {
                            result =  respObj.result.records[i].adult_card_fare_per_ride.toInt()
                        } else if (status == "senior_citizen_cash_fare_per_ride") {
                            result =  respObj.result.records[i].senior_citizen_cash_fare_per_ride.toInt()
                        } else if (status == "persons_with_disabilities_cash_fare_per_ride") {
                            result =  respObj.result.records[i].persons_with_disabilities_cash_fare_per_ride.toInt()
                        } else if (status == "workfare_transport_concessions_card_fare_per_ride") {
                            result =  respObj.result.records[i].workfare_transport_concession_cash_fare_per_ride.toInt()
                        } else if (status == "adult_cash_fare_per_ride") {
                            result =  respObj.result.records[i].adult_cash_fare_per_ride.toInt()
                        } else if (status == "student_cash_fare_per_ride") {
                            result =  respObj.result.records[i].student_cash_fare_per_ride.toInt()
                        }
                    }
                }
            } else if (distance <13.2){
                for (i in 0..respObj.result.records.size - 1) {
                    if (respObj.result.records[i].distance == "12.3 km - 13.2 km") {
                        if (status == "senior_citizen_card_fare_per_ride") {
                            result =  respObj.result.records[i].senior_citizen_card_fare_per_ride.toInt()
                        } else if (status == "student_card_fare_per_ride") {
                            result =  respObj.result.records[i].student_card_fare_per_ride.toInt()
                        } else if (status == "workfare_transport_concession_cash_fare_per_ride") {
                            result =  respObj.result.records[i].workfare_transport_concession_cash_fare_per_ride.toInt()
                        } else if (status == "persons_with_disabilities_card_fare_per_ride") {
                            result =  respObj.result.records[i].persons_with_disabilities_card_fare_per_ride.toInt()
                        } else if (status == "adult_card_fare_per_ride") {
                            result =  respObj.result.records[i].adult_card_fare_per_ride.toInt()
                        } else if (status == "senior_citizen_cash_fare_per_ride") {
                            result =  respObj.result.records[i].senior_citizen_cash_fare_per_ride.toInt()
                        } else if (status == "persons_with_disabilities_cash_fare_per_ride") {
                            result =  respObj.result.records[i].persons_with_disabilities_cash_fare_per_ride.toInt()
                        } else if (status == "workfare_transport_concessions_card_fare_per_ride") {
                            result =  respObj.result.records[i].workfare_transport_concession_cash_fare_per_ride.toInt()
                        } else if (status == "adult_cash_fare_per_ride") {
                            result =  respObj.result.records[i].adult_cash_fare_per_ride.toInt()
                        } else if (status == "student_cash_fare_per_ride") {
                            result =  respObj.result.records[i].student_cash_fare_per_ride.toInt()
                        }
                    }
                }
            } else if (distance <14.2){
                for (i in 0..respObj.result.records.size - 1) {
                    if (respObj.result.records[i].distance == "13.3 km - 14.2 km") {
                        if (status == "senior_citizen_card_fare_per_ride") {
                            result =  respObj.result.records[i].senior_citizen_card_fare_per_ride.toInt()
                        } else if (status == "student_card_fare_per_ride") {
                            result =  respObj.result.records[i].student_card_fare_per_ride.toInt()
                        } else if (status == "workfare_transport_concession_cash_fare_per_ride") {
                            result =  respObj.result.records[i].workfare_transport_concession_cash_fare_per_ride.toInt()
                        } else if (status == "persons_with_disabilities_card_fare_per_ride") {
                            result =  respObj.result.records[i].persons_with_disabilities_card_fare_per_ride.toInt()
                        } else if (status == "adult_card_fare_per_ride") {
                            result =  respObj.result.records[i].adult_card_fare_per_ride.toInt()
                        } else if (status == "senior_citizen_cash_fare_per_ride") {
                            result =  respObj.result.records[i].senior_citizen_cash_fare_per_ride.toInt()
                        } else if (status == "persons_with_disabilities_cash_fare_per_ride") {
                            result =  respObj.result.records[i].persons_with_disabilities_cash_fare_per_ride.toInt()
                        } else if (status == "workfare_transport_concessions_card_fare_per_ride") {
                            result =  respObj.result.records[i].workfare_transport_concession_cash_fare_per_ride.toInt()
                        } else if (status == "adult_cash_fare_per_ride") {
                            result =  respObj.result.records[i].adult_cash_fare_per_ride.toInt()
                        } else if (status == "student_cash_fare_per_ride") {
                            result =  respObj.result.records[i].student_cash_fare_per_ride.toInt()
                        }
                    }
                }
            } else if (distance <15.2){
                for (i in 0..respObj.result.records.size - 1) {
                    if (respObj.result.records[i].distance == "14.3 km - 15.2 km") {
                        if (status == "senior_citizen_card_fare_per_ride") {
                            result =  respObj.result.records[i].senior_citizen_card_fare_per_ride.toInt()
                        } else if (status == "student_card_fare_per_ride") {
                            result =  respObj.result.records[i].student_card_fare_per_ride.toInt()
                        } else if (status == "workfare_transport_concession_cash_fare_per_ride") {
                            result =  respObj.result.records[i].workfare_transport_concession_cash_fare_per_ride.toInt()
                        } else if (status == "persons_with_disabilities_card_fare_per_ride") {
                            result =  respObj.result.records[i].persons_with_disabilities_card_fare_per_ride.toInt()
                        } else if (status == "adult_card_fare_per_ride") {
                            result =  respObj.result.records[i].adult_card_fare_per_ride.toInt()
                        } else if (status == "senior_citizen_cash_fare_per_ride") {
                            result =  respObj.result.records[i].senior_citizen_cash_fare_per_ride.toInt()
                        } else if (status == "persons_with_disabilities_cash_fare_per_ride") {
                            result =  respObj.result.records[i].persons_with_disabilities_cash_fare_per_ride.toInt()
                        } else if (status == "workfare_transport_concessions_card_fare_per_ride") {
                            result =  respObj.result.records[i].workfare_transport_concession_cash_fare_per_ride.toInt()
                        } else if (status == "adult_cash_fare_per_ride") {
                            result =  respObj.result.records[i].adult_cash_fare_per_ride.toInt()
                        } else if (status == "student_cash_fare_per_ride") {
                            result =  respObj.result.records[i].student_cash_fare_per_ride.toInt()
                        }
                    }
                }
            } else if (distance <16.2){
                Log.d("Price","IT RAN")
                for (i in 0..respObj.result.records.size - 1) {
                    if (respObj.result.records[i].distance == "15.3 km - 16.2 km") {
                        if (status == "senior_citizen_card_fare_per_ride") {
                            result =  respObj.result.records[i].senior_citizen_card_fare_per_ride.toInt()
                        } else if (status == "student_card_fare_per_ride") {
                            result =  respObj.result.records[i].student_card_fare_per_ride.toInt()
                        } else if (status == "workfare_transport_concession_cash_fare_per_ride") {
                            result =  respObj.result.records[i].workfare_transport_concession_cash_fare_per_ride.toInt()
                        } else if (status == "persons_with_disabilities_card_fare_per_ride") {
                            result =  respObj.result.records[i].persons_with_disabilities_card_fare_per_ride.toInt()
                        } else if (status == "adult_card_fare_per_ride") {
                            result =  respObj.result.records[i].adult_card_fare_per_ride.toInt()
                        } else if (status == "senior_citizen_cash_fare_per_ride") {
                            result =  respObj.result.records[i].senior_citizen_cash_fare_per_ride.toInt()
                        } else if (status == "persons_with_disabilities_cash_fare_per_ride") {
                            result =  respObj.result.records[i].persons_with_disabilities_cash_fare_per_ride.toInt()
                        } else if (status == "workfare_transport_concessions_card_fare_per_ride") {
                            result =  respObj.result.records[i].workfare_transport_concession_cash_fare_per_ride.toInt()
                        } else if (status == "adult_cash_fare_per_ride") {
                            result =  respObj.result.records[i].adult_cash_fare_per_ride.toInt()
                        } else if (status == "student_cash_fare_per_ride") {
                            result =  respObj.result.records[i].student_cash_fare_per_ride.toInt()
                        }
                    }
                }
            } else if (distance < 17.2){
                for (i in 0..respObj.result.records.size - 1) {
                    if (respObj.result.records[i].distance == "16.3 km - 17.2 km") {
                        if (status == "senior_citizen_card_fare_per_ride") {
                            result =  respObj.result.records[i].senior_citizen_card_fare_per_ride.toInt()
                        } else if (status == "student_card_fare_per_ride") {
                            result =  respObj.result.records[i].student_card_fare_per_ride.toInt()
                        } else if (status == "workfare_transport_concession_cash_fare_per_ride") {
                            result =  respObj.result.records[i].workfare_transport_concession_cash_fare_per_ride.toInt()
                        } else if (status == "persons_with_disabilities_card_fare_per_ride") {
                            result =  respObj.result.records[i].persons_with_disabilities_card_fare_per_ride.toInt()
                        } else if (status == "adult_card_fare_per_ride") {
                            result =  respObj.result.records[i].adult_card_fare_per_ride.toInt()
                        } else if (status == "senior_citizen_cash_fare_per_ride") {
                            result =  respObj.result.records[i].senior_citizen_cash_fare_per_ride.toInt()
                        } else if (status == "persons_with_disabilities_cash_fare_per_ride") {
                            result =  respObj.result.records[i].persons_with_disabilities_cash_fare_per_ride.toInt()
                        } else if (status == "workfare_transport_concessions_card_fare_per_ride") {
                            result =  respObj.result.records[i].workfare_transport_concession_cash_fare_per_ride.toInt()
                        } else if (status == "adult_cash_fare_per_ride") {
                            result =  respObj.result.records[i].adult_cash_fare_per_ride.toInt()
                        } else if (status == "student_cash_fare_per_ride") {
                            result =  respObj.result.records[i].student_cash_fare_per_ride.toInt()
                        }
                    }
                }
            } else if (distance <18.2){
                for (i in 0..respObj.result.records.size - 1) {
                    if (respObj.result.records[i].distance == "17.3 km - 18.2 km") {
                        if (status == "senior_citizen_card_fare_per_ride") {
                            result =  respObj.result.records[i].senior_citizen_card_fare_per_ride.toInt()
                        } else if (status == "student_card_fare_per_ride") {
                            result =  respObj.result.records[i].student_card_fare_per_ride.toInt()
                        } else if (status == "workfare_transport_concession_cash_fare_per_ride") {
                            result =  respObj.result.records[i].workfare_transport_concession_cash_fare_per_ride.toInt()
                        } else if (status == "persons_with_disabilities_card_fare_per_ride") {
                            result =  respObj.result.records[i].persons_with_disabilities_card_fare_per_ride.toInt()
                        } else if (status == "adult_card_fare_per_ride") {
                            result =  respObj.result.records[i].adult_card_fare_per_ride.toInt()
                        } else if (status == "senior_citizen_cash_fare_per_ride") {
                            result =  respObj.result.records[i].senior_citizen_cash_fare_per_ride.toInt()
                        } else if (status == "persons_with_disabilities_cash_fare_per_ride") {
                            result =  respObj.result.records[i].persons_with_disabilities_cash_fare_per_ride.toInt()
                        } else if (status == "workfare_transport_concessions_card_fare_per_ride") {
                            result =  respObj.result.records[i].workfare_transport_concession_cash_fare_per_ride.toInt()
                        } else if (status == "adult_cash_fare_per_ride") {
                            result =  respObj.result.records[i].adult_cash_fare_per_ride.toInt()
                        } else if (status == "student_cash_fare_per_ride") {
                            result =  respObj.result.records[i].student_cash_fare_per_ride.toInt()
                        }
                    }
                }
            } else if (distance <19.2){
                for (i in 0..respObj.result.records.size - 1) {
                    if (respObj.result.records[i].distance == "18.3 km - 19.2 km") {
                        if (status == "senior_citizen_card_fare_per_ride") {
                            result =  respObj.result.records[i].senior_citizen_card_fare_per_ride.toInt()
                        } else if (status == "student_card_fare_per_ride") {
                            result =  respObj.result.records[i].student_card_fare_per_ride.toInt()
                        } else if (status == "workfare_transport_concession_cash_fare_per_ride") {
                            result =  respObj.result.records[i].workfare_transport_concession_cash_fare_per_ride.toInt()
                        } else if (status == "persons_with_disabilities_card_fare_per_ride") {
                            result =  respObj.result.records[i].persons_with_disabilities_card_fare_per_ride.toInt()
                        } else if (status == "adult_card_fare_per_ride") {
                            result =  respObj.result.records[i].adult_card_fare_per_ride.toInt()
                        } else if (status == "senior_citizen_cash_fare_per_ride") {
                            result =  respObj.result.records[i].senior_citizen_cash_fare_per_ride.toInt()
                        } else if (status == "persons_with_disabilities_cash_fare_per_ride") {
                            result =  respObj.result.records[i].persons_with_disabilities_cash_fare_per_ride.toInt()
                        } else if (status == "workfare_transport_concessions_card_fare_per_ride") {
                            result =  respObj.result.records[i].workfare_transport_concession_cash_fare_per_ride.toInt()
                        } else if (status == "adult_cash_fare_per_ride") {
                            result =  respObj.result.records[i].adult_cash_fare_per_ride.toInt()
                        } else if (status == "student_cash_fare_per_ride") {
                            result =  respObj.result.records[i].student_cash_fare_per_ride.toInt()
                        }
                    }
                }
            } else if (distance <20.2){
                for (i in 0..respObj.result.records.size - 1) {
                    if (respObj.result.records[i].distance == "19.3 km - 20.2 km") {
                        if (status == "senior_citizen_card_fare_per_ride") {
                            result =  respObj.result.records[i].senior_citizen_card_fare_per_ride.toInt()
                        } else if (status == "student_card_fare_per_ride") {
                            result =  respObj.result.records[i].student_card_fare_per_ride.toInt()
                        } else if (status == "workfare_transport_concession_cash_fare_per_ride") {
                            result =  respObj.result.records[i].workfare_transport_concession_cash_fare_per_ride.toInt()
                        } else if (status == "persons_with_disabilities_card_fare_per_ride") {
                            result =  respObj.result.records[i].persons_with_disabilities_card_fare_per_ride.toInt()
                        } else if (status == "adult_card_fare_per_ride") {
                            result =  respObj.result.records[i].adult_card_fare_per_ride.toInt()
                        } else if (status == "senior_citizen_cash_fare_per_ride") {
                            result =  respObj.result.records[i].senior_citizen_cash_fare_per_ride.toInt()
                        } else if (status == "persons_with_disabilities_cash_fare_per_ride") {
                            result =  respObj.result.records[i].persons_with_disabilities_cash_fare_per_ride.toInt()
                        } else if (status == "workfare_transport_concessions_card_fare_per_ride") {
                            result =  respObj.result.records[i].workfare_transport_concession_cash_fare_per_ride.toInt()
                        } else if (status == "adult_cash_fare_per_ride") {
                            result =  respObj.result.records[i].adult_cash_fare_per_ride.toInt()
                        } else if (status == "student_cash_fare_per_ride") {
                            result =  respObj.result.records[i].student_cash_fare_per_ride.toInt()
                        }
                    }
                }
            } else if (distance <21.2){
                for (i in 0..respObj.result.records.size - 1) {
                    if (respObj.result.records[i].distance == "20.3 km - 21.2 km") {
                        if (status == "senior_citizen_card_fare_per_ride") {
                            result =  respObj.result.records[i].senior_citizen_card_fare_per_ride.toInt()
                        } else if (status == "student_card_fare_per_ride") {
                            result =  respObj.result.records[i].student_card_fare_per_ride.toInt()
                        } else if (status == "workfare_transport_concession_cash_fare_per_ride") {
                            result =  respObj.result.records[i].workfare_transport_concession_cash_fare_per_ride.toInt()
                        } else if (status == "persons_with_disabilities_card_fare_per_ride") {
                            result =  respObj.result.records[i].persons_with_disabilities_card_fare_per_ride.toInt()
                        } else if (status == "adult_card_fare_per_ride") {
                            result =  respObj.result.records[i].adult_card_fare_per_ride.toInt()
                        } else if (status == "senior_citizen_cash_fare_per_ride") {
                            result =  respObj.result.records[i].senior_citizen_cash_fare_per_ride.toInt()
                        } else if (status == "persons_with_disabilities_cash_fare_per_ride") {
                            result =  respObj.result.records[i].persons_with_disabilities_cash_fare_per_ride.toInt()
                        } else if (status == "workfare_transport_concessions_card_fare_per_ride") {
                            result =  respObj.result.records[i].workfare_transport_concession_cash_fare_per_ride.toInt()
                        } else if (status == "adult_cash_fare_per_ride") {
                            result =  respObj.result.records[i].adult_cash_fare_per_ride.toInt()
                        } else if (status == "student_cash_fare_per_ride") {
                            result =  respObj.result.records[i].student_cash_fare_per_ride.toInt()
                        }
                    }
                }
            }
            else if (distance <22.2){
                for (i in 0..respObj.result.records.size - 1) {
                    if (respObj.result.records[i].distance == "21.3 km - 22.2 km") {
                        if (status == "senior_citizen_card_fare_per_ride") {
                            result =  respObj.result.records[i].senior_citizen_card_fare_per_ride.toInt()
                        } else if (status == "student_card_fare_per_ride") {
                            result =  respObj.result.records[i].student_card_fare_per_ride.toInt()
                        } else if (status == "workfare_transport_concession_cash_fare_per_ride") {
                            result =  respObj.result.records[i].workfare_transport_concession_cash_fare_per_ride.toInt()
                        } else if (status == "persons_with_disabilities_card_fare_per_ride") {
                            result =  respObj.result.records[i].persons_with_disabilities_card_fare_per_ride.toInt()
                        } else if (status == "adult_card_fare_per_ride") {
                            result =  respObj.result.records[i].adult_card_fare_per_ride.toInt()
                        } else if (status == "senior_citizen_cash_fare_per_ride") {
                            result =  respObj.result.records[i].senior_citizen_cash_fare_per_ride.toInt()
                        } else if (status == "persons_with_disabilities_cash_fare_per_ride") {
                            result =  respObj.result.records[i].persons_with_disabilities_cash_fare_per_ride.toInt()
                        } else if (status == "workfare_transport_concessions_card_fare_per_ride") {
                            result =  respObj.result.records[i].workfare_transport_concession_cash_fare_per_ride.toInt()
                        } else if (status == "adult_cash_fare_per_ride") {
                            result =  respObj.result.records[i].adult_cash_fare_per_ride.toInt()
                        } else if (status == "student_cash_fare_per_ride") {
                            result =  respObj.result.records[i].student_cash_fare_per_ride.toInt()
                        }
                    }
                }
            }
            else if (distance <23.2){
                for (i in 0..respObj.result.records.size - 1) {
                    if (respObj.result.records[i].distance == "22.3 km - 23.2 km") {
                        if (status == "senior_citizen_card_fare_per_ride") {
                            result =  respObj.result.records[i].senior_citizen_card_fare_per_ride.toInt()
                        } else if (status == "student_card_fare_per_ride") {
                            result =  respObj.result.records[i].student_card_fare_per_ride.toInt()
                        } else if (status == "workfare_transport_concession_cash_fare_per_ride") {
                            result =  respObj.result.records[i].workfare_transport_concession_cash_fare_per_ride.toInt()
                        } else if (status == "persons_with_disabilities_card_fare_per_ride") {
                            result =  respObj.result.records[i].persons_with_disabilities_card_fare_per_ride.toInt()
                        } else if (status == "adult_card_fare_per_ride") {
                            result =  respObj.result.records[i].adult_card_fare_per_ride.toInt()
                        } else if (status == "senior_citizen_cash_fare_per_ride") {
                            result =  respObj.result.records[i].senior_citizen_cash_fare_per_ride.toInt()
                        } else if (status == "persons_with_disabilities_cash_fare_per_ride") {
                            result =  respObj.result.records[i].persons_with_disabilities_cash_fare_per_ride.toInt()
                        } else if (status == "workfare_transport_concessions_card_fare_per_ride") {
                            result =  respObj.result.records[i].workfare_transport_concession_cash_fare_per_ride.toInt()
                        } else if (status == "adult_cash_fare_per_ride") {
                            result =  respObj.result.records[i].adult_cash_fare_per_ride.toInt()
                        } else if (status == "student_cash_fare_per_ride") {
                            result =  respObj.result.records[i].student_cash_fare_per_ride.toInt()
                        }
                    }
                }
            }
            else if (distance < 24.2){
                for (i in 0..respObj.result.records.size - 1) {
                    if (respObj.result.records[i].distance == "23.3 km - 24.2 km") {
                        if (status == "senior_citizen_card_fare_per_ride") {
                            result =  respObj.result.records[i].senior_citizen_card_fare_per_ride.toInt()
                        } else if (status == "student_card_fare_per_ride") {
                            result =  respObj.result.records[i].student_card_fare_per_ride.toInt()
                        } else if (status == "workfare_transport_concession_cash_fare_per_ride") {
                            result =  respObj.result.records[i].workfare_transport_concession_cash_fare_per_ride.toInt()
                        } else if (status == "persons_with_disabilities_card_fare_per_ride") {
                            result =  respObj.result.records[i].persons_with_disabilities_card_fare_per_ride.toInt()
                        } else if (status == "adult_card_fare_per_ride") {
                            result =  respObj.result.records[i].adult_card_fare_per_ride.toInt()
                        } else if (status == "senior_citizen_cash_fare_per_ride") {
                            result =  respObj.result.records[i].senior_citizen_cash_fare_per_ride.toInt()
                        } else if (status == "persons_with_disabilities_cash_fare_per_ride") {
                            result =  respObj.result.records[i].persons_with_disabilities_cash_fare_per_ride.toInt()
                        } else if (status == "workfare_transport_concessions_card_fare_per_ride") {
                            result =  respObj.result.records[i].workfare_transport_concession_cash_fare_per_ride.toInt()
                        } else if (status == "adult_cash_fare_per_ride") {
                            result =  respObj.result.records[i].adult_cash_fare_per_ride.toInt()
                        } else if (status == "student_cash_fare_per_ride") {
                            result =  respObj.result.records[i].student_cash_fare_per_ride.toInt()
                        }
                    }
                }
            }
            else if (distance < 25.2){
                for (i in 0..respObj.result.records.size - 1) {
                    if (respObj.result.records[i].distance == "24.3 km - 25.2 km") {
                        if (status == "senior_citizen_card_fare_per_ride") {
                            result =  respObj.result.records[i].senior_citizen_card_fare_per_ride.toInt()
                        } else if (status == "student_card_fare_per_ride") {
                            result =  respObj.result.records[i].student_card_fare_per_ride.toInt()
                        } else if (status == "workfare_transport_concession_cash_fare_per_ride") {
                            result =  respObj.result.records[i].workfare_transport_concession_cash_fare_per_ride.toInt()
                        } else if (status == "persons_with_disabilities_card_fare_per_ride") {
                            result =  respObj.result.records[i].persons_with_disabilities_card_fare_per_ride.toInt()
                        } else if (status == "adult_card_fare_per_ride") {
                            result =  respObj.result.records[i].adult_card_fare_per_ride.toInt()
                        } else if (status == "senior_citizen_cash_fare_per_ride") {
                            result =  respObj.result.records[i].senior_citizen_cash_fare_per_ride.toInt()
                        } else if (status == "persons_with_disabilities_cash_fare_per_ride") {
                            result =  respObj.result.records[i].persons_with_disabilities_cash_fare_per_ride.toInt()
                        } else if (status == "workfare_transport_concessions_card_fare_per_ride") {
                            result =  respObj.result.records[i].workfare_transport_concession_cash_fare_per_ride.toInt()
                        } else if (status == "adult_cash_fare_per_ride") {
                            result =  respObj.result.records[i].adult_cash_fare_per_ride.toInt()
                        } else if (status == "student_cash_fare_per_ride") {
                            result =  respObj.result.records[i].student_cash_fare_per_ride.toInt()
                        }
                    }
                }
            }
            else if (distance <26.2){
                for (i in 0..respObj.result.records.size - 1) {
                    if (respObj.result.records[i].distance == "25.3 km - 26.2 km") {
                        if (status == "senior_citizen_card_fare_per_ride") {
                            result =  respObj.result.records[i].senior_citizen_card_fare_per_ride.toInt()
                        } else if (status == "student_card_fare_per_ride") {
                            result =  respObj.result.records[i].student_card_fare_per_ride.toInt()
                        } else if (status == "workfare_transport_concession_cash_fare_per_ride") {
                            result =  respObj.result.records[i].workfare_transport_concession_cash_fare_per_ride.toInt()
                        } else if (status == "persons_with_disabilities_card_fare_per_ride") {
                            result =  respObj.result.records[i].persons_with_disabilities_card_fare_per_ride.toInt()
                        } else if (status == "adult_card_fare_per_ride") {
                            result =  respObj.result.records[i].adult_card_fare_per_ride.toInt()
                        } else if (status == "senior_citizen_cash_fare_per_ride") {
                            result =  respObj.result.records[i].senior_citizen_cash_fare_per_ride.toInt()
                        } else if (status == "persons_with_disabilities_cash_fare_per_ride") {
                            result =  respObj.result.records[i].persons_with_disabilities_cash_fare_per_ride.toInt()
                        } else if (status == "workfare_transport_concessions_card_fare_per_ride") {
                            result =  respObj.result.records[i].workfare_transport_concession_cash_fare_per_ride.toInt()
                        } else if (status == "adult_cash_fare_per_ride") {
                            result =  respObj.result.records[i].adult_cash_fare_per_ride.toInt()
                        } else if (status == "student_cash_fare_per_ride") {
                            result =  respObj.result.records[i].student_cash_fare_per_ride.toInt()
                        }
                    }
                }
            }
            else if (distance <27.2){
                for (i in 0..respObj.result.records.size - 1) {
                    if (respObj.result.records[i].distance == "26.3 km - 27.2 km") {
                        if (status == "senior_citizen_card_fare_per_ride") {
                            result =  respObj.result.records[i].senior_citizen_card_fare_per_ride.toInt()
                        } else if (status == "student_card_fare_per_ride") {
                            result =  respObj.result.records[i].student_card_fare_per_ride.toInt()
                        } else if (status == "workfare_transport_concession_cash_fare_per_ride") {
                            result =  respObj.result.records[i].workfare_transport_concession_cash_fare_per_ride.toInt()
                        } else if (status == "persons_with_disabilities_card_fare_per_ride") {
                            result =  respObj.result.records[i].persons_with_disabilities_card_fare_per_ride.toInt()
                        } else if (status == "adult_card_fare_per_ride") {
                            result =  respObj.result.records[i].adult_card_fare_per_ride.toInt()
                        } else if (status == "senior_citizen_cash_fare_per_ride") {
                            result =  respObj.result.records[i].senior_citizen_cash_fare_per_ride.toInt()
                        } else if (status == "persons_with_disabilities_cash_fare_per_ride") {
                            result =  respObj.result.records[i].persons_with_disabilities_cash_fare_per_ride.toInt()
                        } else if (status == "workfare_transport_concessions_card_fare_per_ride") {
                            result =  respObj.result.records[i].workfare_transport_concession_cash_fare_per_ride.toInt()
                        } else if (status == "adult_cash_fare_per_ride") {
                            result =  respObj.result.records[i].adult_cash_fare_per_ride.toInt()
                        } else if (status == "student_cash_fare_per_ride") {
                            result =  respObj.result.records[i].student_cash_fare_per_ride.toInt()
                        }
                    }
                }
            }
            else if (distance <28.2){
                for (i in 0..respObj.result.records.size - 1) {
                    if (respObj.result.records[i].distance == "27.3 km - 28.2 km") {
                        if (status == "senior_citizen_card_fare_per_ride") {
                            result =  respObj.result.records[i].senior_citizen_card_fare_per_ride.toInt()
                        } else if (status == "student_card_fare_per_ride") {
                            result =  respObj.result.records[i].student_card_fare_per_ride.toInt()
                        } else if (status == "workfare_transport_concession_cash_fare_per_ride") {
                            result =  respObj.result.records[i].workfare_transport_concession_cash_fare_per_ride.toInt()
                        } else if (status == "persons_with_disabilities_card_fare_per_ride") {
                            result =  respObj.result.records[i].persons_with_disabilities_card_fare_per_ride.toInt()
                        } else if (status == "adult_card_fare_per_ride") {
                            result =  respObj.result.records[i].adult_card_fare_per_ride.toInt()
                        } else if (status == "senior_citizen_cash_fare_per_ride") {
                            result =  respObj.result.records[i].senior_citizen_cash_fare_per_ride.toInt()
                        } else if (status == "persons_with_disabilities_cash_fare_per_ride") {
                            result =  respObj.result.records[i].persons_with_disabilities_cash_fare_per_ride.toInt()
                        } else if (status == "workfare_transport_concessions_card_fare_per_ride") {
                            result =  respObj.result.records[i].workfare_transport_concession_cash_fare_per_ride.toInt()
                        } else if (status == "adult_cash_fare_per_ride") {
                            result =  respObj.result.records[i].adult_cash_fare_per_ride.toInt()
                        } else if (status == "student_cash_fare_per_ride") {
                            result =  respObj.result.records[i].student_cash_fare_per_ride.toInt()
                        }
                    }
                }
            }
            else if (distance <29.2){
                for (i in 0..respObj.result.records.size - 1) {
                    if (respObj.result.records[i].distance == "28.3 km - 29.2 km") {
                        if (status == "senior_citizen_card_fare_per_ride") {
                            result =  respObj.result.records[i].senior_citizen_card_fare_per_ride.toInt()
                        } else if (status == "student_card_fare_per_ride") {
                            result =  respObj.result.records[i].student_card_fare_per_ride.toInt()
                        } else if (status == "workfare_transport_concession_cash_fare_per_ride") {
                            result =  respObj.result.records[i].workfare_transport_concession_cash_fare_per_ride.toInt()
                        } else if (status == "persons_with_disabilities_card_fare_per_ride") {
                            result =  respObj.result.records[i].persons_with_disabilities_card_fare_per_ride.toInt()
                        } else if (status == "adult_card_fare_per_ride") {
                            result =  respObj.result.records[i].adult_card_fare_per_ride.toInt()
                        } else if (status == "senior_citizen_cash_fare_per_ride") {
                            result =  respObj.result.records[i].senior_citizen_cash_fare_per_ride.toInt()
                        } else if (status == "persons_with_disabilities_cash_fare_per_ride") {
                            result =  respObj.result.records[i].persons_with_disabilities_cash_fare_per_ride.toInt()
                        } else if (status == "workfare_transport_concessions_card_fare_per_ride") {
                            result =  respObj.result.records[i].workfare_transport_concession_cash_fare_per_ride.toInt()
                        } else if (status == "adult_cash_fare_per_ride") {
                            result =  respObj.result.records[i].adult_cash_fare_per_ride.toInt()
                        } else if (status == "student_cash_fare_per_ride") {
                            result =  respObj.result.records[i].student_cash_fare_per_ride.toInt()
                        }
                    }
                }
            }
            else if (distance <30.2){
                for (i in 0..respObj.result.records.size - 1) {
                    if (respObj.result.records[i].distance == "29.3 km - 30.2 km") {
                        if (status == "senior_citizen_card_fare_per_ride") {
                            result =  respObj.result.records[i].senior_citizen_card_fare_per_ride.toInt()
                        } else if (status == "student_card_fare_per_ride") {
                            result =  respObj.result.records[i].student_card_fare_per_ride.toInt()
                        } else if (status == "workfare_transport_concession_cash_fare_per_ride") {
                            result =  respObj.result.records[i].workfare_transport_concession_cash_fare_per_ride.toInt()
                        } else if (status == "persons_with_disabilities_card_fare_per_ride") {
                            result =  respObj.result.records[i].persons_with_disabilities_card_fare_per_ride.toInt()
                        } else if (status == "adult_card_fare_per_ride") {
                            result =  respObj.result.records[i].adult_card_fare_per_ride.toInt()
                        } else if (status == "senior_citizen_cash_fare_per_ride") {
                            result =  respObj.result.records[i].senior_citizen_cash_fare_per_ride.toInt()
                        } else if (status == "persons_with_disabilities_cash_fare_per_ride") {
                            result =  respObj.result.records[i].persons_with_disabilities_cash_fare_per_ride.toInt()
                        } else if (status == "workfare_transport_concessions_card_fare_per_ride") {
                            result =  respObj.result.records[i].workfare_transport_concession_cash_fare_per_ride.toInt()
                        } else if (status == "adult_cash_fare_per_ride") {
                            result =  respObj.result.records[i].adult_cash_fare_per_ride.toInt()
                        } else if (status == "student_cash_fare_per_ride") {
                            result =  respObj.result.records[i].student_cash_fare_per_ride.toInt()
                        }
                    }
                }
            }
            else if (distance < 31.2){
                for (i in 0..respObj.result.records.size - 1) {
                    if (respObj.result.records[i].distance == "30.3 km - 31.2 km") {
                        if (status == "senior_citizen_card_fare_per_ride") {
                            result =  respObj.result.records[i].senior_citizen_card_fare_per_ride.toInt()
                        } else if (status == "student_card_fare_per_ride") {
                            result =  respObj.result.records[i].student_card_fare_per_ride.toInt()
                        } else if (status == "workfare_transport_concession_cash_fare_per_ride") {
                            result =  respObj.result.records[i].workfare_transport_concession_cash_fare_per_ride.toInt()
                        } else if (status == "persons_with_disabilities_card_fare_per_ride") {
                            result =  respObj.result.records[i].persons_with_disabilities_card_fare_per_ride.toInt()
                        } else if (status == "adult_card_fare_per_ride") {
                            result =  respObj.result.records[i].adult_card_fare_per_ride.toInt()
                        } else if (status == "senior_citizen_cash_fare_per_ride") {
                            result =  respObj.result.records[i].senior_citizen_cash_fare_per_ride.toInt()
                        } else if (status == "persons_with_disabilities_cash_fare_per_ride") {
                            result =  respObj.result.records[i].persons_with_disabilities_cash_fare_per_ride.toInt()
                        } else if (status == "workfare_transport_concessions_card_fare_per_ride") {
                            result =  respObj.result.records[i].workfare_transport_concession_cash_fare_per_ride.toInt()
                        } else if (status == "adult_cash_fare_per_ride") {
                            result =  respObj.result.records[i].adult_cash_fare_per_ride.toInt()
                        } else if (status == "student_cash_fare_per_ride") {
                            result =  respObj.result.records[i].student_cash_fare_per_ride.toInt()
                        }
                    }
                }
            }
            else if (distance <32.2){
                for (i in 0..respObj.result.records.size - 1) {
                    if (respObj.result.records[i].distance == "31.3 km - 32.2 km") {
                        if (status == "senior_citizen_card_fare_per_ride") {
                            result =  respObj.result.records[i].senior_citizen_card_fare_per_ride.toInt()
                        } else if (status == "student_card_fare_per_ride") {
                            result =  respObj.result.records[i].student_card_fare_per_ride.toInt()
                        } else if (status == "workfare_transport_concession_cash_fare_per_ride") {
                            result =  respObj.result.records[i].workfare_transport_concession_cash_fare_per_ride.toInt()
                        } else if (status == "persons_with_disabilities_card_fare_per_ride") {
                            result =  respObj.result.records[i].persons_with_disabilities_card_fare_per_ride.toInt()
                        } else if (status == "adult_card_fare_per_ride") {
                            result =  respObj.result.records[i].adult_card_fare_per_ride.toInt()
                        } else if (status == "senior_citizen_cash_fare_per_ride") {
                            result =  respObj.result.records[i].senior_citizen_cash_fare_per_ride.toInt()
                        } else if (status == "persons_with_disabilities_cash_fare_per_ride") {
                            result =  respObj.result.records[i].persons_with_disabilities_cash_fare_per_ride.toInt()
                        } else if (status == "workfare_transport_concessions_card_fare_per_ride") {
                            result =  respObj.result.records[i].workfare_transport_concession_cash_fare_per_ride.toInt()
                        } else if (status == "adult_cash_fare_per_ride") {
                            result =  respObj.result.records[i].adult_cash_fare_per_ride.toInt()
                        } else if (status == "student_cash_fare_per_ride") {
                            result =  respObj.result.records[i].student_cash_fare_per_ride.toInt()
                        }
                    }
                }
            }
            else if (distance <33.2){
                for (i in 0..respObj.result.records.size - 1) {
                    if (respObj.result.records[i].distance == "32.3 km - 33.2 km") {
                        if (status == "senior_citizen_card_fare_per_ride") {
                            result =  respObj.result.records[i].senior_citizen_card_fare_per_ride.toInt()
                        } else if (status == "student_card_fare_per_ride") {
                            result =  respObj.result.records[i].student_card_fare_per_ride.toInt()
                        } else if (status == "workfare_transport_concession_cash_fare_per_ride") {
                            result =  respObj.result.records[i].workfare_transport_concession_cash_fare_per_ride.toInt()
                        } else if (status == "persons_with_disabilities_card_fare_per_ride") {
                            result =  respObj.result.records[i].persons_with_disabilities_card_fare_per_ride.toInt()
                        } else if (status == "adult_card_fare_per_ride") {
                            result =  respObj.result.records[i].adult_card_fare_per_ride.toInt()
                        } else if (status == "senior_citizen_cash_fare_per_ride") {
                            result =  respObj.result.records[i].senior_citizen_cash_fare_per_ride.toInt()
                        } else if (status == "persons_with_disabilities_cash_fare_per_ride") {
                            result =  respObj.result.records[i].persons_with_disabilities_cash_fare_per_ride.toInt()
                        } else if (status == "workfare_transport_concessions_card_fare_per_ride") {
                            result =  respObj.result.records[i].workfare_transport_concession_cash_fare_per_ride.toInt()
                        } else if (status == "adult_cash_fare_per_ride") {
                            result =  respObj.result.records[i].adult_cash_fare_per_ride.toInt()
                        } else if (status == "student_cash_fare_per_ride") {
                            result =  respObj.result.records[i].student_cash_fare_per_ride.toInt()
                        }
                    }
                }
            }
            else if (distance <34.2){
                for (i in 0..respObj.result.records.size - 1) {
                    if (respObj.result.records[i].distance == "33.3 km - 34.2 km") {
                        if (status == "senior_citizen_card_fare_per_ride") {
                            result =  respObj.result.records[i].senior_citizen_card_fare_per_ride.toInt()
                        } else if (status == "student_card_fare_per_ride") {
                            result =  respObj.result.records[i].student_card_fare_per_ride.toInt()
                        } else if (status == "workfare_transport_concession_cash_fare_per_ride") {
                            result =  respObj.result.records[i].workfare_transport_concession_cash_fare_per_ride.toInt()
                        } else if (status == "persons_with_disabilities_card_fare_per_ride") {
                            result =  respObj.result.records[i].persons_with_disabilities_card_fare_per_ride.toInt()
                        } else if (status == "adult_card_fare_per_ride") {
                            result =  respObj.result.records[i].adult_card_fare_per_ride.toInt()
                        } else if (status == "senior_citizen_cash_fare_per_ride") {
                            result =  respObj.result.records[i].senior_citizen_cash_fare_per_ride.toInt()
                        } else if (status == "persons_with_disabilities_cash_fare_per_ride") {
                            result =  respObj.result.records[i].persons_with_disabilities_cash_fare_per_ride.toInt()
                        } else if (status == "workfare_transport_concessions_card_fare_per_ride") {
                            result =  respObj.result.records[i].workfare_transport_concession_cash_fare_per_ride.toInt()
                        } else if (status == "adult_cash_fare_per_ride") {
                            result =  respObj.result.records[i].adult_cash_fare_per_ride.toInt()
                        } else if (status == "student_cash_fare_per_ride") {
                            result =  respObj.result.records[i].student_cash_fare_per_ride.toInt()
                        }
                    }
                }
            }
            else if (distance <35.2){
                for (i in 0..respObj.result.records.size - 1) {
                    if (respObj.result.records[i].distance == "34.3 km - 35.2 km") {
                        if (status == "senior_citizen_card_fare_per_ride") {
                            result =  respObj.result.records[i].senior_citizen_card_fare_per_ride.toInt()
                        } else if (status == "student_card_fare_per_ride") {
                            result =  respObj.result.records[i].student_card_fare_per_ride.toInt()
                        } else if (status == "workfare_transport_concession_cash_fare_per_ride") {
                            result =  respObj.result.records[i].workfare_transport_concession_cash_fare_per_ride.toInt()
                        } else if (status == "persons_with_disabilities_card_fare_per_ride") {
                            result =  respObj.result.records[i].persons_with_disabilities_card_fare_per_ride.toInt()
                        } else if (status == "adult_card_fare_per_ride") {
                            result =  respObj.result.records[i].adult_card_fare_per_ride.toInt()
                        } else if (status == "senior_citizen_cash_fare_per_ride") {
                            result =  respObj.result.records[i].senior_citizen_cash_fare_per_ride.toInt()
                        } else if (status == "persons_with_disabilities_cash_fare_per_ride") {
                            result =  respObj.result.records[i].persons_with_disabilities_cash_fare_per_ride.toInt()
                        } else if (status == "workfare_transport_concessions_card_fare_per_ride") {
                            result =  respObj.result.records[i].workfare_transport_concession_cash_fare_per_ride.toInt()
                        } else if (status == "adult_cash_fare_per_ride") {
                            result =  respObj.result.records[i].adult_cash_fare_per_ride.toInt()
                        } else if (status == "student_cash_fare_per_ride") {
                            result =  respObj.result.records[i].student_cash_fare_per_ride.toInt()
                        }
                    }
                }
            }
            else if (distance <36.2){
                for (i in 0..respObj.result.records.size - 1) {
                    if (respObj.result.records[i].distance == "35.3 km - 36.2 km") {
                        if (status == "senior_citizen_card_fare_per_ride") {
                            result =  respObj.result.records[i].senior_citizen_card_fare_per_ride.toInt()
                        } else if (status == "student_card_fare_per_ride") {
                            result =  respObj.result.records[i].student_card_fare_per_ride.toInt()
                        } else if (status == "workfare_transport_concession_cash_fare_per_ride") {
                            result =  respObj.result.records[i].workfare_transport_concession_cash_fare_per_ride.toInt()
                        } else if (status == "persons_with_disabilities_card_fare_per_ride") {
                            result =  respObj.result.records[i].persons_with_disabilities_card_fare_per_ride.toInt()
                        } else if (status == "adult_card_fare_per_ride") {
                            result =  respObj.result.records[i].adult_card_fare_per_ride.toInt()
                        } else if (status == "senior_citizen_cash_fare_per_ride") {
                            result =  respObj.result.records[i].senior_citizen_cash_fare_per_ride.toInt()
                        } else if (status == "persons_with_disabilities_cash_fare_per_ride") {
                            result =  respObj.result.records[i].persons_with_disabilities_cash_fare_per_ride.toInt()
                        } else if (status == "workfare_transport_concessions_card_fare_per_ride") {
                            result =  respObj.result.records[i].workfare_transport_concession_cash_fare_per_ride.toInt()
                        } else if (status == "adult_cash_fare_per_ride") {
                            result =  respObj.result.records[i].adult_cash_fare_per_ride.toInt()
                        } else if (status == "student_cash_fare_per_ride") {
                            result =  respObj.result.records[i].student_cash_fare_per_ride.toInt()
                        }
                    }
                }
            }
            else if (distance <37.2){
                for (i in 0..respObj.result.records.size - 1) {
                    if (respObj.result.records[i].distance == "36.3 km - 37.2 km") {
                        if (status == "senior_citizen_card_fare_per_ride") {
                            result =  respObj.result.records[i].senior_citizen_card_fare_per_ride.toInt()
                        } else if (status == "student_card_fare_per_ride") {
                            result =  respObj.result.records[i].student_card_fare_per_ride.toInt()
                        } else if (status == "workfare_transport_concession_cash_fare_per_ride") {
                            result =  respObj.result.records[i].workfare_transport_concession_cash_fare_per_ride.toInt()
                        } else if (status == "persons_with_disabilities_card_fare_per_ride") {
                            result =  respObj.result.records[i].persons_with_disabilities_card_fare_per_ride.toInt()
                        } else if (status == "adult_card_fare_per_ride") {
                            result =  respObj.result.records[i].adult_card_fare_per_ride.toInt()
                        } else if (status == "senior_citizen_cash_fare_per_ride") {
                            result =  respObj.result.records[i].senior_citizen_cash_fare_per_ride.toInt()
                        } else if (status == "persons_with_disabilities_cash_fare_per_ride") {
                            result =  respObj.result.records[i].persons_with_disabilities_cash_fare_per_ride.toInt()
                        } else if (status == "workfare_transport_concessions_card_fare_per_ride") {
                            result =  respObj.result.records[i].workfare_transport_concession_cash_fare_per_ride.toInt()
                        } else if (status == "adult_cash_fare_per_ride") {
                            result =  respObj.result.records[i].adult_cash_fare_per_ride.toInt()
                        } else if (status == "student_cash_fare_per_ride") {
                            result =  respObj.result.records[i].student_cash_fare_per_ride.toInt()
                        }
                    }
                }
            }
            else if (distance <38.2){
                for (i in 0..respObj.result.records.size - 1) {
                    if (respObj.result.records[i].distance == "37.3 km - 38.2 km") {
                        if (status == "senior_citizen_card_fare_per_ride") {
                            result =  respObj.result.records[i].senior_citizen_card_fare_per_ride.toInt()
                        } else if (status == "student_card_fare_per_ride") {
                            result =  respObj.result.records[i].student_card_fare_per_ride.toInt()
                        } else if (status == "workfare_transport_concession_cash_fare_per_ride") {
                            result =  respObj.result.records[i].workfare_transport_concession_cash_fare_per_ride.toInt()
                        } else if (status == "persons_with_disabilities_card_fare_per_ride") {
                            result =  respObj.result.records[i].persons_with_disabilities_card_fare_per_ride.toInt()
                        } else if (status == "adult_card_fare_per_ride") {
                            result =  respObj.result.records[i].adult_card_fare_per_ride.toInt()
                        } else if (status == "senior_citizen_cash_fare_per_ride") {
                            result =  respObj.result.records[i].senior_citizen_cash_fare_per_ride.toInt()
                        } else if (status == "persons_with_disabilities_cash_fare_per_ride") {
                            result =  respObj.result.records[i].persons_with_disabilities_cash_fare_per_ride.toInt()
                        } else if (status == "workfare_transport_concessions_card_fare_per_ride") {
                            result =  respObj.result.records[i].workfare_transport_concession_cash_fare_per_ride.toInt()
                        } else if (status == "adult_cash_fare_per_ride") {
                            result =  respObj.result.records[i].adult_cash_fare_per_ride.toInt()
                        } else if (status == "student_cash_fare_per_ride") {
                            result =  respObj.result.records[i].student_cash_fare_per_ride.toInt()
                        }
                    }
                }
            }
            else if (distance <39.2){
                for (i in 0..respObj.result.records.size - 1) {
                    if (respObj.result.records[i].distance == "38.3 km - 39.2 km") {
                        if (status == "senior_citizen_card_fare_per_ride") {
                            result =  respObj.result.records[i].senior_citizen_card_fare_per_ride.toInt()
                        } else if (status == "student_card_fare_per_ride") {
                            result =  respObj.result.records[i].student_card_fare_per_ride.toInt()
                        } else if (status == "workfare_transport_concession_cash_fare_per_ride") {
                            result =  respObj.result.records[i].workfare_transport_concession_cash_fare_per_ride.toInt()
                        } else if (status == "persons_with_disabilities_card_fare_per_ride") {
                            result =  respObj.result.records[i].persons_with_disabilities_card_fare_per_ride.toInt()
                        } else if (status == "adult_card_fare_per_ride") {
                            result =  respObj.result.records[i].adult_card_fare_per_ride.toInt()
                        } else if (status == "senior_citizen_cash_fare_per_ride") {
                            result =  respObj.result.records[i].senior_citizen_cash_fare_per_ride.toInt()
                        } else if (status == "persons_with_disabilities_cash_fare_per_ride") {
                            result =  respObj.result.records[i].persons_with_disabilities_cash_fare_per_ride.toInt()
                        } else if (status == "workfare_transport_concessions_card_fare_per_ride") {
                            result =  respObj.result.records[i].workfare_transport_concession_cash_fare_per_ride.toInt()
                        } else if (status == "adult_cash_fare_per_ride") {
                            result =  respObj.result.records[i].adult_cash_fare_per_ride.toInt()
                        } else if (status == "student_cash_fare_per_ride") {
                            result =  respObj.result.records[i].student_cash_fare_per_ride.toInt()
                        }
                    }
                }
            }
            else if (distance < 40.2){
                for (i in 0..respObj.result.records.size - 1) {
                    if (respObj.result.records[i].distance == "39.3 km - 40.2 km") {
                        if (status == "senior_citizen_card_fare_per_ride") {
                            result =  respObj.result.records[i].senior_citizen_card_fare_per_ride.toInt()
                        } else if (status == "student_card_fare_per_ride") {
                            result =  respObj.result.records[i].student_card_fare_per_ride.toInt()
                        } else if (status == "workfare_transport_concession_cash_fare_per_ride") {
                            result =  respObj.result.records[i].workfare_transport_concession_cash_fare_per_ride.toInt()
                        } else if (status == "persons_with_disabilities_card_fare_per_ride") {
                            result =  respObj.result.records[i].persons_with_disabilities_card_fare_per_ride.toInt()
                        } else if (status == "adult_card_fare_per_ride") {
                            result =  respObj.result.records[i].adult_card_fare_per_ride.toInt()
                        } else if (status == "senior_citizen_cash_fare_per_ride") {
                            result =  respObj.result.records[i].senior_citizen_cash_fare_per_ride.toInt()
                        } else if (status == "persons_with_disabilities_cash_fare_per_ride") {
                            result =  respObj.result.records[i].persons_with_disabilities_cash_fare_per_ride.toInt()
                        } else if (status == "workfare_transport_concessions_card_fare_per_ride") {
                            result =  respObj.result.records[i].workfare_transport_concession_cash_fare_per_ride.toInt()
                        } else if (status == "adult_cash_fare_per_ride") {
                            result =  respObj.result.records[i].adult_cash_fare_per_ride.toInt()
                        } else if (status == "student_cash_fare_per_ride") {
                            result =  respObj.result.records[i].student_cash_fare_per_ride.toInt()
                        }
                    }
                }
            }
            else{
                for (i in 0..respObj.result.records.size - 1) {
                    if (respObj.result.records[i].distance == "Over 40.2 km") {
                        if (status == "senior_citizen_card_fare_per_ride") {
                            result =  respObj.result.records[i].senior_citizen_card_fare_per_ride.toInt()
                        } else if (status == "student_card_fare_per_ride") {
                            result =  respObj.result.records[i].student_card_fare_per_ride.toInt()
                        } else if (status == "workfare_transport_concession_cash_fare_per_ride") {
                            result =  respObj.result.records[i].workfare_transport_concession_cash_fare_per_ride.toInt()
                        } else if (status == "persons_with_disabilities_card_fare_per_ride") {
                            result =  respObj.result.records[i].persons_with_disabilities_card_fare_per_ride.toInt()
                        } else if (status == "adult_card_fare_per_ride") {
                            result =  respObj.result.records[i].adult_card_fare_per_ride.toInt()
                        } else if (status == "senior_citizen_cash_fare_per_ride") {
                            result =  respObj.result.records[i].senior_citizen_cash_fare_per_ride.toInt()
                        } else if (status == "persons_with_disabilities_cash_fare_per_ride") {
                            result =  respObj.result.records[i].persons_with_disabilities_cash_fare_per_ride.toInt()
                        } else if (status == "workfare_transport_concessions_card_fare_per_ride") {
                            result =  respObj.result.records[i].workfare_transport_concession_cash_fare_per_ride.toInt()
                        } else if (status == "adult_cash_fare_per_ride") {
                            result =  respObj.result.records[i].adult_cash_fare_per_ride.toInt()
                        } else if (status == "student_cash_fare_per_ride") {
                            result =  respObj.result.records[i].student_cash_fare_per_ride.toInt()
                        }
                    }
                }
            }
            return result
        }

}