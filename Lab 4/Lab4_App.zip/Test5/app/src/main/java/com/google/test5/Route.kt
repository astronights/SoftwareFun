package com.google.test5

import android.os.Parcel
import android.os.Parcelable


class Route {
    var routes = ArrayList<Routes>()

}

class Routes {
    var legs = ArrayList<Legs>()
}

class Legs {
    var distance = Distance()
    var duration = Duration()
    var end_address = ""
    var start_address = ""
    var end_location =Location()
    var start_location = Location()
    var steps = ArrayList<Steps>()
    var departure_time = GTime()
    var arrival_time = GTime()
}
class GTime{
    var text =""
}

class Steps {
    var distance = Distance()
    var duration = Duration()
    var end_address = ""
    var start_address = ""
    var end_location =Location()
    var start_location = Location()
    var polyline = PolyLine()
    var travel_mode = ""
    var html_instructions = ""
    var transit_details = TransitDetails()

}
class TransitDetails{
    var line = Line()
    var arrival_stop = Stop()
    var departure_stop = Stop()
}
class Stop{
    var name = ""
}
class Line{
    var name =""
    var short_name=""
    var vehicle= Vehicle()
}
class Vehicle{
    var name =""
}

class Duration {
    var text = ""
    var value = 0
}

class Distance {
    var text = ""
    var value = 0
}

class PolyLine {
    var points = ""
}

class Location{
    var lat =""
    var lng =""
}