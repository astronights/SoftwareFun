package com.google.test5

import android.content.Context
import com.google.gson.Gson
import android.content.ContextWrapper
import android.content.SharedPreferences
import android.support.v7.app.AppCompatActivity

class control_activity_hist: AppCompatActivity()  {

    private var listItems = ArrayList<Item>()
    var numOfObjects = id1;

    fun getHistory(ctx: Context, sharedPreferences: SharedPreferences): ArrayList<Item> {
        // Create SharedPreferences object.


        for (i in 0..numOfObjects - 1) {
            var userInfoListJsonString3 = sharedPreferences.getString(i.toString(), "")
            var gson = Gson()
            var post2 = gson.fromJson(userInfoListJsonString3, Route::class.java)
            var userInfoDto1 = post2
            var travel_mode = userInfoDto1.routes[0].legs[0].steps[0].travel_mode
            var bus = false
            var mrt = true
            if (travel_mode == 0.toString()) {
                var bus = true;
                var mrt = true;
            } else if (travel_mode == 1.toString()) {
                var bus = true;
                var mrt = false;
            }

            var obj: Item = Item(
                i,
                "From" + userInfoDto1.routes[0].legs[0].start_address + " to " + userInfoDto1.routes[0].legs[0].end_address,
                userInfoDto1.routes[0].legs[0].start_address,
                userInfoDto1.routes[0].legs[0].end_address,
                bus,
                mrt,
                userInfoDto1.routes[0].legs[0].departure_time.text,
                userInfoDto1.routes[0].legs[0].arrival_time.text
            )
            listItems.add(obj)
        }
        return listItems
    }


}