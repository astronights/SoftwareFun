package com.google.test5

import android.content.Context
import android.support.v7.widget.RecyclerView
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView

class PictureAdapter (private val context: Context,private val allRoutes:ArrayList<Routes>): RecyclerView.Adapter<PictureAdapter.ViewHolder>(){
    private val inflater: LayoutInflater = context.getSystemService(Context.LAYOUT_INFLATER_SERVICE) as LayoutInflater
    override fun onBindViewHolder(p0: ViewHolder, p1: Int) {
        p0.routeicon.setImageResource(R.drawable.north_east_line_logo)
    }
    override fun onCreateViewHolder(p0: ViewGroup, p1: Int): PictureAdapter.ViewHolder {
        Log.d("Doggy","OnCreateViewHolder")
        val view : View = inflater.inflate(R.layout.picture_row,p0,false)
        return ViewHolder(view)
    }
    override fun getItemCount(): Int = allRoutes.size
    class ViewHolder(itemView: View):RecyclerView.ViewHolder(itemView) {
        val routeicon : ImageView = itemView.findViewById(R.id.routeicon)
    }
}