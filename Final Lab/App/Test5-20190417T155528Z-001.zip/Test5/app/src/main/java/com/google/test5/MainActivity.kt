package com.google.test5

import android.content.Intent
import android.os.Bundle
import android.support.design.widget.BottomNavigationView
import android.support.v7.app.AppCompatActivity
import android.support.v7.widget.LinearLayoutManager
import android.support.v7.widget.OrientationHelper
import android.util.Log
import android.widget.CheckBox
import android.widget.Toast
import kotlinx.android.synthetic.main.activity_main.*
import kotlinx.android.synthetic.main.results.*

class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        navigation.setOnNavigationItemSelectedListener(mOnNavigationItemSelectedListener)
        btnFindPath.setOnClickListener {
            sendRequest()

        }
    }
    fun sendRequest() {
        var origin = etOrigin.getText().toString()
        var destination: String = etDestination.getText().toString()
        var a:Int=-1
        if (findViewById<CheckBox>(R.id.checkBox).isChecked && findViewById<CheckBox>(R.id.checkBox2).isChecked){
            a= 0
        }
        else if(findViewById<CheckBox>(R.id.checkBox).isChecked){
            a=1
        }
        else if(findViewById<CheckBox>(R.id.checkBox2).isChecked){
            a=2
        }
        else{
            a=3
            Toast.makeText(this,"Please check the transit options",Toast.LENGTH_SHORT).show()
        }


        if (origin.isEmpty()) {
            Toast.makeText(this, "please enter origin address", Toast.LENGTH_SHORT).show()
            return
        } else if (destination.isEmpty()) {
            Toast.makeText(this, "Please enter destination address", Toast.LENGTH_SHORT).show()
            return
        }
        else if (a==3){
            Toast.makeText(this, "Please select at least one mode of transport", Toast.LENGTH_SHORT).show()
            return
        }
        else {
            var intent = Intent(this, DirectionActivity::class.java).apply {
                putExtra("origin", origin)
                putExtra("destination", destination)
                putExtra("mode",a)
            }

            startActivity(intent)
        }


    }


    private val mOnNavigationItemSelectedListener = BottomNavigationView.OnNavigationItemSelectedListener { item ->
        when (item.itemId) {
            R.id.navigation_search -> {
                val intent1=Intent(this,MainActivity::class.java).apply(){}
                startActivity(intent1)

                return@OnNavigationItemSelectedListener true
            }
            R.id.navigation_current -> {
                val intent1= Intent(this,MapsActivity::class.java).apply(){}
                intent1.putExtra("position",RouteSave.pos)
                startActivity(intent1)
                return@OnNavigationItemSelectedListener true
            }
            R.id.navigation_hist -> {
                val intent1 = Intent(this, activity_hist::class.java).apply(){}
                startActivity(intent1)
                return@OnNavigationItemSelectedListener true
            }
            R.id.navigation_fav -> {
                val intent1 = Intent(this,activity_fav::class.java).apply(){}
                startActivity(intent1)
                return@OnNavigationItemSelectedListener true
            }
        }
        false
    }
}
