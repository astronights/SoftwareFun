package com.google.test5

class FareDTO{
    var result = Result()
}
class Result{
    var records = ArrayList<Records>()
}
class Records{
    var distance = ""
    var senior_citizen_cash_fare_per_ride = ""
    var persons_with_disabilities_card_fare_per_ride = ""
    var adult_card_fare_per_ride = ""
    var senior_citizen_card_fare_per_ride  = ""
    var student_card_fare_per_ride = ""
    var workfare_transport_concession_cash_fare_per_ride = ""
    var persons_with_disabilities_cash_fare_per_ride = ""
    var workfare_transport_concession_card_fare_per_ride = ""
    var adult_cash_fare_per_ride = ""
    var student_cash_fare_per_ride = ""
    var _id = ""
}