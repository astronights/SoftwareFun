package com.google.test5

import android.content.Context
import com.google.gson.Gson
import android.content.ContextWrapper
import android.content.SharedPreferences
import android.support.v7.app.AppCompatActivity
import android.widget.Toast

class control_activity_fav: AppCompatActivity()  {

    private var listItems = ArrayList<Item>()
    var numOfObjects = id_favorite;

    // private val USER_INFO_LIST_TAG = "USER_INFO_LIST_TAG"
    private val FAVORITE = "favorite"

    // This is the saved UserInfoDTO list jason string key in sharedpreferences file..
    private val SHARED_PREFERENCES_KEY_USER_INFO_LIST = "User_Info_List"

    // This is the debug log info tag which will be printed in the android monitor console.
    private val USER_INFO_LIST_TAG = "USER_INFO_LIST_TAG"

    fun setFavorite (obj: Routes, ctx: Context, sharedPreferences: SharedPreferences) {
        // First initialize a list of UserInfoDTO.
        val initialUserInfoList: Routes = obj

        // Create Gson object.
        val gson = Gson()

        // Get java object list json format string.
        val userInfoListJsonString = gson.toJson(initialUserInfoList)

        // Put the json format string to SharedPreferences object.
        val editor = sharedPreferences.edit()

        editor.putString(id_favorite.toString(), userInfoListJsonString)
        id_favorite++
//            Toast.makeText(ctx, userInfoListJsonString, Toast.LENGTH_SHORT)
//                .show()
        editor.apply()
        //Popup a toast message in screen bottom.
//        Toast.makeText(ctx, id_favorite.toString() + " Route has been Saved to storage", Toast.LENGTH_SHORT)
//            .show()

    }

    fun getFavorites(ctx: Context, sharedPreferences: SharedPreferences): ArrayList<Item> {
        // Create SharedPreferences object.
        for (i in 0..numOfObjects - 1) {
            var userInfoListJsonString3 = sharedPreferences.getString(i.toString(), "")
            var gson = Gson()
            var post2 = gson.fromJson(userInfoListJsonString3, Routes::class.java)
            var userInfoDto1 = post2
            var travel_mode = userInfoDto1.legs[0].steps[0].travel_mode
            var bus = false
            var mrt = true
            var fav = false
            if (travel_mode == 0.toString()) {
                var bus = true;
                var mrt = true;
            } else if (travel_mode == 1.toString()) {
                var bus = true;
                var mrt = false;
            }
            if (favouriteRoutes[i]==true){
                fav = true
            }

            var obj: Item = Item(
                i,
                "From " + userInfoDto1.legs[0].start_address + " to " + userInfoDto1.legs[0].end_address,
                userInfoDto1.legs[0].start_address,
                userInfoDto1.legs[0].end_address,
                bus,
                mrt,
                userInfoDto1.legs[0].departure_time.text,
                userInfoDto1.legs[0].arrival_time.text,
                fav
            )
            listItems.add(obj)
        }
        return listItems
    }


    fun delFavorite (position: Int, ctx:Context) {
        // getFavorites()
        val preferences = ctx.getSharedPreferences(position.toString(), Context.MODE_PRIVATE)
        preferences.edit().clear().apply();
        id_favorite --;
        // Find matching object in list
        // Delete object
        // setFavorites()
    }

}