package com.google.test5

import android.content.Context
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.BaseAdapter
import android.widget.ImageView
import android.widget.TextView
import javax.sql.DataSource
import kotlinx.android.synthetic.main.results.*

class DirectionAdapter(private val context: Context, private val dataSource:ArrayList<Routes>):BaseAdapter() {
    private val inflater: LayoutInflater
            = context.getSystemService(Context.LAYOUT_INFLATER_SERVICE) as LayoutInflater

    override fun getCount(): Int {
        return dataSource.size
    }
    override fun getItem(position: Int): Any {
        return dataSource[position]
    }
    override fun getItemId(position: Int): Long {
        return position.toLong()
    }
    override fun getView(position: Int, convertView: View?, parent: ViewGroup): View {
        // Get view for row item
        val rowView = inflater.inflate(R.layout.results, parent, false)

        // Get title element
        val titleTextView = rowView.findViewById(R.id.recipe_list_title) as TextView
// Get detail element
        val detailTextView = rowView.findViewById(R.id.recipe_list_detail) as TextView
        val subtitleTextView = rowView.findViewById(R.id.text1) as TextView
        val fareTextView = rowView.findViewById(R.id.fare) as TextView
        val routes = getItem(position) as Routes
        val iconOne =  rowView.findViewById(R.id.iconOne1) as ImageView
        val textOne = rowView.findViewById(R.id.textOne1) as TextView
        val iconTwo=  rowView.findViewById(R.id.iconTwo1) as ImageView
        val textTwo = rowView.findViewById(R.id.textTwo1) as TextView
        val iconThree=  rowView.findViewById(R.id.iconThree1) as ImageView
        val textThree = rowView.findViewById(R.id.textThree1) as TextView
// 2
        var title : String=""
        var subtitle : String =""
        var detail: String = ""
        var totaldistance: Double = 0.0
        for (i in 0..routes.legs[0].steps.size-1){
            if (routes.legs[0].steps[i].transit_details.line.vehicle.name == "Bus"){
                title += routes.legs[0].steps[i].transit_details.line.vehicle.name+" "+routes.legs[0].steps[i].transit_details.line.short_name+"->"
                subtitle += routes.legs[0].steps[i].transit_details.departure_stop.name+"-"+routes.legs[0].steps[i].transit_details.arrival_stop.name+"->"
                totaldistance += routes.legs[0].steps[i].distance.value.toDouble()/1000
            }else if (routes.legs[0].steps[i].transit_details.line.vehicle.name == "Subway"){
                title += routes.legs[0].steps[i].transit_details.line.name+"->"
                subtitle += routes.legs[0].steps[i].transit_details.departure_stop.name+" Station-"+routes.legs[0].steps[i].transit_details.arrival_stop.name+" Station->"
                totaldistance += routes.legs[0].steps[i].distance.value.toDouble()/1000
            }
        }


        titleTextView.text = title.substring(0,title.length-2)
        detailTextView.text = routes.legs[0].duration.text
        subtitleTextView.text = subtitle.substring(0,subtitle.length-2)
        fareTextView.text = "Fare is $"+(Fare(totaldistance,"adult_card_fare_per_ride").getFare().toDouble()/100).toString()
        var a = 0
        for (i in 0..(routes.legs[0].steps.size-1)){
            if (routes.legs[0].steps[i].travel_mode== "TRANSIT"){
                if (routes.legs[0].steps[i].transit_details.line.vehicle.name == "Bus"){
                    if (a==0){
                        iconOne.setImageResource(R.drawable.ic_bus)
                        textOne.text = routes.legs[0].steps[i].transit_details.line.short_name
                        a++
                    }else if (a == 1){
                        iconTwo.setImageResource(R.drawable.ic_bus)
                        textTwo.text = routes.legs[0].steps[i].transit_details.line.short_name
                        a++
                    }else if (a == 2){
                        iconThree.setImageResource(R.drawable.ic_bus)
                        textThree.text = routes.legs[0].steps[i].transit_details.line.short_name
                        a++
                    }
                }else if (routes.legs[0].steps[i].transit_details.line.vehicle.name == "Subway"){
                    if (a==0){
                        iconOne.setImageResource(R.drawable.ic_mrt)
                        textOne.text = routes.legs[0].steps[i].transit_details.line.name
                        a++
                    }else if (a == 1){
                        iconTwo.setImageResource(R.drawable.ic_mrt)
                        textTwo.text = routes.legs[0].steps[i].transit_details.line.name
                        a++
                    }else if (a == 2){
                        iconThree.setImageResource(R.drawable.ic_mrt)
                        textThree.text = routes.legs[0].steps[i].transit_details.line.name
                        a++
                    }
                }
            }
        }
        return rowView
    }
}