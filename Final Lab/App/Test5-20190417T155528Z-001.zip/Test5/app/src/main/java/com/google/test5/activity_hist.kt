package com.google.test5
import java.io.Serializable
import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.support.design.widget.BottomNavigationView
import android.support.v7.app.AppCompatActivity
import android.util.Log
import android.view.LayoutInflater
import android.view.MenuItem
import android.view.View
import android.view.ViewGroup
import android.widget.*
import com.google.gson.Gson
import kotlinx.android.synthetic.main.activity_direction.*
import kotlinx.android.synthetic.main.activity_main.*
import java.util.Arrays.asList
//import org.omg.CORBA.TRANSIENT
import com.google.gson.GsonBuilder
import java.lang.reflect.Modifier
import java.util.*
import java.util.Arrays.asList
import android.content.SharedPreferences
import com.google.gson.reflect.TypeToken
import kotlinx.android.synthetic.main.activity_direction.*
import java.lang.reflect.Type
import kotlin.collections.ArrayList

var id_favorite = 0
class activity_hist: AppCompatActivity() {
    var clicked: Boolean = false
    private var listItems = ArrayList<Item>()  // Should contain all information needed about route
    private val HISTORY = "history"
    private val FAVORITE = "favorite"
    var logic: control_activity_hist = control_activity_hist()
    lateinit var sharedPreferences : SharedPreferences

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        //add code of if have history if local history
        //setContentView(R.layout.activity_no_history)
        if(id1 == 0){
            setContentView(R.layout.activity_no_history)
            navigation()
        }
        else {
            setContentView(R.layout.activity_direction)
            navigation()
            val ctx = applicationContext
            sharedPreferences = ctx.getSharedPreferences(HISTORY, Context.MODE_PRIVATE)
            listItems = logic.getHistory(ctx,sharedPreferences)
            var itemsAdapter = itemsAdapter(this, listItems)
            listView_1.adapter = itemsAdapter
            listView_1.onItemClickListener = AdapterView.OnItemClickListener { adapterView, view, position, id ->
                Toast.makeText(this, "Click on " + listItems[position].title, Toast.LENGTH_SHORT).show()

            }
        }
    }
    fun navigation(){

        val navigation = findViewById<BottomNavigationView>(R.id.navigation)

        navigation.getMenu().getItem(2).setChecked(true);
        navigation?.setOnNavigationItemSelectedListener OnNavigationItemSelectedListener@{ item : MenuItem ->
            //            item.isChecked = true
//            navigation.itemIconTintList = null;
            when (item.itemId) {
                R.id.navigation_search -> {


                    if(clicked){
                        val a = Intent(this@activity_hist, MainActivity::class.java)
                        //setContentView(R.layout.activity_p1)
                        startActivity(a)
                    }
                    else{
                        val a = Intent(this@activity_hist, MainActivity::class.java)
                        //setContentView(R.layout.activity_p1)
                        startActivity(a)
                    }
                    return@OnNavigationItemSelectedListener true
                }
                R.id.navigation_current -> {
                    // navigation.itemIconTintList = null;
                    //item.setIcon(R.drawable.ic_currentroute)
                    val a = Intent(this@activity_hist, MapsActivity::class.java)
                    a.putExtra("position",RouteSave.pos)
                    startActivity(a)
                    return@OnNavigationItemSelectedListener true
                }
                R.id.navigation_fav -> {
                    //  navigation.itemIconTintList = null;
                    //item.setIcon(R.drawable.ic_favourite)
                    val b = Intent(this@activity_hist, activity_fav::class.java)
                    startActivity(b)
                    return@OnNavigationItemSelectedListener true
                }
                R.id.navigation_hist -> {

                    return@OnNavigationItemSelectedListener true
                }
            }
            false
        }
    }

    inner class itemsAdapter : BaseAdapter {

        private var itemsList = ArrayList<Item>()
        private var context: Context? = null

        constructor(context: Context, itemsList: ArrayList<Item>) : super() {
            this.itemsList = itemsList
            this.context = context
        }

        override fun getView(position: Int, convertView: View?, parent: ViewGroup?): View? {

            val view: View?
            val vh: ViewHolder

            if (convertView == null) {
                view = layoutInflater.inflate(R.layout.activity_item, parent, false)
                vh = ViewHolder(view)
                view.tag = vh
                Log.i("JSA", "set Tag for ViewHolder, position: " + position)
            } else {
                view = convertView
                vh = view.tag as ViewHolder
            }

            // Assigning information in view
            vh.tvTitle.text = itemsList[position].title
            val hist = context!!.getSharedPreferences("history",Context.MODE_PRIVATE)
            val histRoute : Routes = Gson().fromJson(hist.getString(position.toString(),""),Routes::class.java)
            var a : Int = 0
            for (i in 0..(histRoute.legs[0].steps.size-1)){
                if (histRoute.legs[0].steps[i].travel_mode== "TRANSIT"){
                    if (histRoute.legs[0].steps[i].transit_details.line.vehicle.name == "Bus"){
                        if (a==0){
                            vh.iconOne.setImageResource(R.drawable.ic_bus)
                            vh.textOne.text = histRoute.legs[0].steps[i].transit_details.line.short_name
                            a++
                        }else if (a == 1){
                            vh.iconTwo.setImageResource(R.drawable.ic_bus)
                            vh.textTwo.text = histRoute.legs[0].steps[i].transit_details.line.short_name
                            a++
                        }else if (a == 2){
                            vh.iconThree.setImageResource(R.drawable.ic_bus)
                            vh.textThree.text = histRoute.legs[0].steps[i].transit_details.line.short_name
                            a++
                        }
                    }else if (histRoute.legs[0].steps[i].transit_details.line.vehicle.name == "Subway"){
                        if (a==0){
                            vh.iconOne.setImageResource(R.drawable.ic_mrt)
                            vh.textOne.text = histRoute.legs[0].steps[i].transit_details.line.name
                            a++
                        }else if (a == 1){
                            vh.iconTwo.setImageResource(R.drawable.ic_mrt)
                            vh.textTwo.text = histRoute.legs[0].steps[i].transit_details.line.name
                            a++
                        }else if (a == 2){
                            vh.iconThree.setImageResource(R.drawable.ic_mrt)
                            vh.textThree.text = histRoute.legs[0].steps[i].transit_details.line.name
                            a++
                        }
                    }
                }
            }
            vh.tvDepTime.text = histRoute.legs[0].duration.text
//added

            // Set default star to empty
            if (itemsList[position].fav == false){
                vh.starFilled.visibility  =  View.GONE
                vh.starEmpty.visibility = View.VISIBLE}
            else{
                vh.starFilled.visibility = View.VISIBLE
            }

            // Set listener to start route button
            vh.startRoute.setOnClickListener {
                Toast.makeText(this@activity_hist, "You clicked me.", Toast.LENGTH_SHORT).show()

                // Launch search activity and pass object
                val intent = Intent(this@activity_hist, MapsActivity::class.java)
                intent.putExtra("position",0) // Pass object to new activity
                RouteSave.pos = 0
                RouteSave.routes[0] = Gson().fromJson(sharedPreferences.getString(position.toString(),""),Routes::class.java)
                startActivity(intent)
            }


            // Handle click on stars
            vh.starEmpty.setOnClickListener {
                Toast.makeText(this@activity_hist, "Add to favorites.", Toast.LENGTH_SHORT).show()
                vh.starFilled.visibility = View.VISIBLE
                vh.starEmpty.visibility = View.GONE
                // Create SharedPreferences object.
                val ctx = applicationContext
                val sharedPreferencesFav =
                    ctx.getSharedPreferences(FAVORITE, Context.MODE_PRIVATE)
                // Add to favorite
                favouriteRoutes[position]=true
                favId.add(position)

                control_activity_fav().setFavorite(Gson().fromJson(sharedPreferences.getString(position.toString(),""),Routes::class.java), ctx, sharedPreferencesFav)

            }

            vh.starFilled.setOnClickListener {
                Toast.makeText(this@activity_hist, "Deleted route from favorites.", Toast.LENGTH_SHORT).show()
                favouriteRoutes[position]=false
                vh.starFilled.visibility = View.GONE
                vh.starEmpty.visibility = View.VISIBLE
                var x = position
                val ctx = applicationContext
                control_activity_fav().delFavorite(favId.indexOf(position),ctx)
                favId.remove(position)
            }

            // Set listener to start route button
            /*
            vh.startRoute.setOnClickListener {
                Toast.makeText(this@History, "You clicked me.", Toast.LENGTH_SHORT).show()

                // Call on new activity
                val intent = Intent(this@History, test::class.java)
                intent.putExtra("selectedRoute", itemsList[position] as Serializable) // Pass object to new activity
                startActivity(intent)

                // Pass along route information to the Start Route activity, to fill in form automatically
            }*/


            // Handle click on stars
            /*
            vh.starFilled.setOnClickListener {
                Toast.makeText(this@History, "Deleted route from favorites.", Toast.LENGTH_SHORT).show()
                itemsList.removeAt(position)
                vh.starFilled.visibility = View.GONE
                vh.starEmpty.visibility = View.VISIBLE
            }
            */

            return view
        }

        override fun getItem(position: Int): Any {
            return itemsList[position]
        }

        override fun getItemId(position: Int): Long {
            return position.toLong()
        }

        override fun getCount(): Int {
            return itemsList.size
        }
    }

    private class ViewHolder(view: View?) {
        val tvTitle: TextView
        val iconOne: ImageView
        val textOne: TextView
        val iconTwo: ImageView
        val textTwo: TextView
        val iconThree: ImageView
        val textThree: TextView
        val tvDepTime: TextView
        val startRoute: ImageButton
        val starEmpty: ImageButton
        val starFilled: ImageButton


        init {
            this.tvTitle = view?.findViewById(R.id.tvTitle) as TextView
            this.iconOne = view?.findViewById(R.id.iconOne) as ImageView
            this.textOne = view?.findViewById(R.id.textOne) as TextView
            this.iconTwo = view?.findViewById(R.id.iconTwo) as ImageView
            this.textTwo = view?.findViewById(R.id.textTwo) as TextView
            this.iconThree = view?.findViewById(R.id.iconThree) as ImageView
            this.textThree = view?.findViewById(R.id.textThree) as TextView
            this.tvDepTime = view?.findViewById(R.id.tvDepartTime) as TextView
            this.startRoute = view?.findViewById(R.id.startRouteArrow) as ImageButton
            this.starEmpty = view?.findViewById(R.id.starEmpty) as ImageButton
            this.starFilled = view?.findViewById(R.id.starFilled) as ImageButton
        }

        //  if you target API 26, you should change to:
//        init {
//            this.tvTitle = view?.findViewById<TextView>(R.id.tvTitle) as TextView
//            this.tvContent = view?.findViewById<TextView>(R.id.tvContent) as TextView
//        }
    }
    @Override
    fun onClick(v: View) {
        // TODO Auto-generated method stub
        clicked = true;
        //write your codes here
    }

}
