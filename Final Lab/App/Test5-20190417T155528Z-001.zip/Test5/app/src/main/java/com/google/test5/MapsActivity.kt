package com.google.test5

import android.app.Activity
import android.content.Intent
import android.content.IntentSender
import android.content.pm.PackageManager
import android.location.Geocoder
import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import android.support.v4.app.ActivityCompat
import android.widget.Toast
import com.google.android.gms.location.*

import com.google.android.gms.maps.CameraUpdateFactory
import com.google.android.gms.maps.GoogleMap
import com.google.android.gms.maps.OnMapReadyCallback
import com.google.android.gms.maps.SupportMapFragment
import com.google.android.gms.maps.model.LatLng
import com.google.android.gms.maps.model.Marker
import com.google.android.gms.maps.model.MarkerOptions
import android.location.Location
import android.util.Log
import com.google.android.gms.common.api.ResolvableApiException
import kotlinx.android.synthetic.main.activity_main.*
import android.location.Address
import android.support.design.widget.BottomNavigationView
import android.view.MenuItem
import android.view.View
import android.widget.TextView
import com.google.android.gms.maps.model.PolylineOptions
import kotlinx.android.synthetic.main.activity_maps.*
import java.io.IOException

class MapsActivity : AppCompatActivity(), OnMapReadyCallback,GoogleMap.OnMarkerClickListener {


    override fun onMarkerClick(p0: Marker?): Boolean {
        return false
    }

    private lateinit var mMap: GoogleMap
    private lateinit var lastLocation: Location

    private lateinit var fusedLocationClient: FusedLocationProviderClient
    companion object {
        private const val LOCATION_PERMISSION_REQUEST_CODE = 1
        private const val REQUEST_CHECK_SETTINGS = 2
    }
    private lateinit var locationCallback: LocationCallback
    private lateinit var locationRequest: LocationRequest
    private var locationUpdateState = false
    private var geofenceList = ArrayList<Geofence>()
    private var geofenceUtils = GeofenceUtil(this)
    var pos : Int = 0
    var clicked = false


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_maps)
        navigation()
        // Obtain the SupportMapFragment and get notified when the map is ready to be used.
        val mapFragment = supportFragmentManager
            .findFragmentById(R.id.map) as SupportMapFragment
        mapFragment.getMapAsync(this)
        fusedLocationClient = LocationServices.getFusedLocationProviderClient(this)
        locationCallback = object : LocationCallback() {
            override fun onLocationResult(p0: LocationResult) {
                super.onLocationResult(p0)

                lastLocation = p0.lastLocation
            }
        }
        createLocationRequest()
        geofenceUtils.geofencingClient = LocationServices.getGeofencingClient(this)

    }
    private fun setUpMap() {
        if (ActivityCompat.checkSelfPermission(this,
                android.Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this,
                arrayOf(android.Manifest.permission.ACCESS_FINE_LOCATION), LOCATION_PERMISSION_REQUEST_CODE)
            return
        }
    }

    private fun placeMarkerOnMap(location: LatLng) {
        mMap.addMarker(MarkerOptions().position(location).title(getAddress(location)))
    }


    /**
     * Manipulates the map once available.
     * This callback is triggered when the map is ready to be used.
     * This is where we can add markers or lines, add listeners or move the camera. In this case,
     * we just add a marker near Sydney, Australia.
     * If Google Play services is not installed on the device, the user will be prompted to install
     * it inside the SupportMapFragment. This method will only be triggered once the user has
     * installed Google Play services and returned to the app.
     */
    override fun onMapReady(googleMap: GoogleMap) {
        mMap = googleMap
        mMap.getUiSettings().setZoomControlsEnabled(true)
        mMap.setOnMarkerClickListener(this)
        setUpMap()
        // 1
        mMap.isMyLocationEnabled = true
        // 2
        fusedLocationClient.lastLocation.addOnSuccessListener(this) { location ->
            // Got last known location. In some rare situations this can be null.
            // 3
            if (location != null) {
                lastLocation = location
                val currentLatLng = LatLng(location.latitude, location.longitude)
                mMap.animateCamera(CameraUpdateFactory.newLatLngZoom(currentLatLng, 12f))
            }
        }

        pos = intent.getIntExtra("position",-1)
        if (pos!=-1) {
            drawRoute()
            placeMarkers()
            geofenceUtils.removeGeofence()
            /*for (i in 0..RouteSave.routes[pos].legs[0].steps.size - 1) {
                if (RouteSave.routes[pos].legs[0].steps[i].transit_details.line.vehicle.name == "Bus") {
                    placeGeofence()
                    break
                }
            }*/
            var instruc = 1
            var textView: TextView = findViewById(R.id.textmap) as TextView
            textView.text = RouteSave.routes[pos].legs[0].steps[0].html_instructions
            buttonMap.setOnClickListener() {
                geofenceUtils.removeGeofence()
                if (instruc == RouteSave.routes[pos].legs[0].steps.size) {
                    textView.text = "You have reached your Destination"
                } else {
                    if (RouteSave.routes[pos].legs[0].steps[instruc].transit_details.line.vehicle.name == "Bus"){
                        textView.text = "Take Bus "+RouteSave.routes[pos].legs[0].steps[instruc].transit_details.line.short_name+ RouteSave.routes[pos].legs[0].steps[instruc].html_instructions.substring(3)
                        Log.d("Test","Placed GeoFence")
                        geofenceUtils.buildGeofence(LatLng(RouteSave.routes[pos].legs[0].steps[instruc].end_location.lat.toDouble(),RouteSave.routes[pos].legs[0].steps[instruc].end_location.lng.toDouble()))
                        geofenceUtils.addGeofence()
                    }else if (RouteSave.routes[pos].legs[0].steps[instruc].transit_details.line.vehicle.name == "Subway"){

                        textView.text = RouteSave.routes[pos].legs[0].steps[instruc].transit_details.line.name + RouteSave.routes[pos].legs[0].steps[instruc].html_instructions.substring(6)+" alight at "+RouteSave.routes[pos].legs[0].steps[instruc].transit_details.arrival_stop.name

                    }else{
                        textView.text = RouteSave.routes[pos].legs[0].steps[instruc].html_instructions
                    }
                    instruc += 1

                }
            }
        }
    }
    fun drawRoute(){
        val path = ArrayList<LatLng>()
        for (i in 0..(RouteSave.routes[pos].legs[0].steps.size-1)){
            path.addAll(decodePolyline(RouteSave.routes[pos].legs[0].steps[i].polyline.points))
        }
        val lineoption = PolylineOptions()
        lineoption.addAll(path)
        lineoption.width(10f)
        lineoption.geodesic(true)
        mMap.addPolyline(lineoption)
    }

    private fun getAddress(latLng: LatLng): String {
        // 1
        val geocoder = Geocoder(this)
        val addresses: List<Address>?
        var addressText = ""

        try {
            // 2
            addresses = geocoder.getFromLocation(latLng.latitude, latLng.longitude, 1)
            //Toast.makeText(this,"Address is "+addresses[0].getAddressLine(0) , Toast.LENGTH_LONG).show()
            addressText =  addresses[0].getAddressLine(0)
        } catch (e: IOException) {
            Log.e("MapsActivity", e.localizedMessage)
        }
        //Toast.makeText(this,"The Address is "+ addressText, Toast.LENGTH_LONG).show()
        return addressText
    }
    private fun startLocationUpdates() {
        //1
        if (ActivityCompat.checkSelfPermission(this,
                android.Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this,
                arrayOf(android.Manifest.permission.ACCESS_FINE_LOCATION),
                LOCATION_PERMISSION_REQUEST_CODE)
            return
        }
        //2
        fusedLocationClient.requestLocationUpdates(locationRequest, locationCallback, null /* Looper */)
    }
    private fun createLocationRequest() {
        // 1
        locationRequest = LocationRequest()
        // 2
        locationRequest.interval = 10000
        // 3
        locationRequest.fastestInterval = 5000
        locationRequest.priority = LocationRequest.PRIORITY_HIGH_ACCURACY

        val builder = LocationSettingsRequest.Builder()
            .addLocationRequest(locationRequest)

        // 4
        val client = LocationServices.getSettingsClient(this)
        val task = client.checkLocationSettings(builder.build())

        // 5
        task.addOnSuccessListener {
            locationUpdateState = true
            startLocationUpdates()
        }
        task.addOnFailureListener { e ->
            // 6
            if (e is ResolvableApiException) {
                // Location settings are not satisfied, but this can be fixed
                // by showing the user a dialog.
                try {
                    // Show the dialog by calling startResolutionForResult(),
                    // and check the result in onActivityResult().
                    e.startResolutionForResult(this@MapsActivity,
                        REQUEST_CHECK_SETTINGS)
                } catch (sendEx: IntentSender.SendIntentException) {
                    // Ignore the error.
                }
            }
        }
    }

    // 1
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == REQUEST_CHECK_SETTINGS) {
            if (resultCode == Activity.RESULT_OK) {
                locationUpdateState = true
                startLocationUpdates()
            }
        }
    }

    // 2
    override fun onPause() {
        super.onPause()
        fusedLocationClient.removeLocationUpdates(locationCallback)
    }

    // 3
    public override fun onResume() {
        super.onResume()
        if (!locationUpdateState) {
            startLocationUpdates()
        }
    }
    public fun decodePolyline(encoded: String): List<LatLng> {

        val poly = ArrayList<LatLng>()
        var index = 0
        val len = encoded.length
        var lat = 0
        var lng = 0

        while (index < len) {
            var b: Int
            var shift = 0
            var result = 0
            do {
                b = encoded[index++].toInt() - 63
                result = result or (b and 0x1f shl shift)
                shift += 5
            } while (b >= 0x20)
            val dlat = if (result and 1 != 0) (result shr 1).inv() else result shr 1
            lat += dlat

            shift = 0
            result = 0
            do {
                b = encoded[index++].toInt() - 63
                result = result or (b and 0x1f shl shift)
                shift += 5
            } while (b >= 0x20)
            val dlng = if (result and 1 != 0) (result shr 1).inv() else result shr 1
            lng += dlng

            val latLng = LatLng((lat.toDouble() / 1E5),(lng.toDouble() / 1E5))
            poly.add(latLng)
        }

        return poly
    }
    fun placeMarkers(){
        for (i in 0..(RouteSave.routes[pos].legs[0].steps.size-1)) {
            if (RouteSave.routes[pos].legs[0].steps[i].travel_mode == "TRANSIT") {
                var title = RouteSave.routes[pos].legs[0].steps[i].transit_details.arrival_stop.name
                var location = LatLng(
                    RouteSave.routes[pos].legs[0].steps[i].end_location.lat.toDouble(),
                    RouteSave.routes[pos].legs[0].steps[i].end_location.lng.toDouble()
                )
                mMap.addMarker(MarkerOptions().position(location).title(title))
            }
        }
        for (i in 0..(RouteSave.routes[pos].legs[0].steps.size-1)){
            if (RouteSave.routes[pos].legs[0].steps[i].travel_mode == "TRANSIT") {
                var startlocation =  LatLng(
                    RouteSave.routes[pos].legs[0].steps[i].start_location.lat.toDouble(),
                    RouteSave.routes[pos].legs[0].steps[i].start_location.lng.toDouble()
                )
                var starttitle = RouteSave.routes[pos].legs[0].steps[i].transit_details.departure_stop.name
                mMap.addMarker(MarkerOptions().position(startlocation).title(starttitle))
                break
            }
        }
    }
    fun placeGeofence(){
        for (i in 0..(RouteSave.routes[pos].legs[0].steps.size-1)) {
            if (RouteSave.routes[pos].legs[0].steps[i].transit_details.line.vehicle.name =="Bus") {
                Log.d("Doggy","Placed Geofence")
                geofenceUtils.buildGeofence(LatLng(RouteSave.routes[pos].legs[0].steps[i].end_location.lat.toDouble(),RouteSave.routes[pos].legs[0].steps[i].end_location.lng.toDouble()))
            }
        }
        geofenceUtils.addGeofence()
    }
    fun navigation(){
        val navigation = findViewById<BottomNavigationView>(R.id.navigation)

        navigation.getMenu().getItem(1).setChecked(true);
        navigation?.setOnNavigationItemSelectedListener OnNavigationItemSelectedListener@{ item: MenuItem ->
            //            item.isChecked = true
//            navigation.itemIconTintList = null
            when (item.itemId) {
                R.id.navigation_search -> {
//                    navigation.itemIconTintList = null;

                    if(clicked){
                        val a = Intent(this@MapsActivity, MainActivity::class.java)
                        //setContentView(R.layout.activity_p1)
                        startActivity(a)
                    }
                    else{
                        val a = Intent(this@MapsActivity, MainActivity::class.java)
                        a.putExtra("position",RouteSave.pos)
                        startActivity(a)
                    }
                    return@OnNavigationItemSelectedListener true
                }

                R.id.navigation_current -> {
                    return@OnNavigationItemSelectedListener true
                }
                R.id.navigation_fav -> {
                    val c = Intent(this@MapsActivity, activity_fav::class.java)
                    startActivity(c)
                    return@OnNavigationItemSelectedListener true
                }
                R.id.navigation_hist -> {
//                    navigation.itemIconTintList = null;
                    val c = Intent(this@MapsActivity, activity_hist::class.java)
                    startActivity(c)
                    return@OnNavigationItemSelectedListener true
                }
            }
            false
        }
    }
    @Override
    fun onClick(v: View) {
        // TODO Auto-generated method stub
        clicked = true;
        //write your codes here
    }

}
