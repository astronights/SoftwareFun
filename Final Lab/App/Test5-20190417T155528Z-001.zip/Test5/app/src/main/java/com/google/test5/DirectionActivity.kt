package com.google.test5

import android.content.ClipData
import android.content.Context
import android.content.Intent
import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import android.support.design.widget.BottomNavigationView
import android.support.v4.content.ContextCompat.startActivity
import android.support.v7.widget.LinearLayoutManager
import android.support.v7.widget.OrientationHelper
import android.util.Log
import android.view.MenuItem
import android.view.View
import android.widget.AdapterView
import android.widget.ArrayAdapter
import android.widget.ListView
import android.widget.Toast
import com.google.gson.Gson
import kotlinx.android.synthetic.main.activity_direction.*
import kotlinx.android.synthetic.main.results.*
import java.io.*

var id1 = 0
var favouriteRoutes = ArrayList<Boolean>()
var favId = ArrayList<Int>()

class DirectionActivity : AppCompatActivity() {
    var r = ArrayList<String>()
    var allRoute= ArrayList<Routes>()
    var a: Int = -1
    var clicked : Boolean = false
    private val HISTORY = "history"

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_direction)
        navigation()
        val origin = intent.getStringExtra("origin")
        val destination = intent.getStringExtra("destination")
        val mode = intent.getIntExtra("mode", 0)
        allRoute = Direction(getDirectionURL(origin, destination, mode)).getResp()
        RouteSave.routes.clear()
        RouteSave.routes.addAll(allRoute)
        Log.d("Dog","Size of RouteSave is "+RouteSave.routes.size.toString())
        Log.d("Dog","Size of allRoute is "+allRoute.size.toString())
        lateinit var listView: ListView
        //val adapter = ArrayAdapter(this, R.layout.results, r)
        //listView = findViewById(R.id.listView_1) as ListView
        //listView.adapter = adapter
        listView=findViewById<ListView>(R.id.listView_1)

        val adapter=DirectionAdapter(this, allRoute)
        listView.adapter=adapter
        //pictures.layoutManager = LinearLayoutManager(this, OrientationHelper.HORIZONTAL,false)
        //pictures.adapter = PictureAdapter(this,RouteSave.routes)

        listView.onItemClickListener = object : AdapterView.OnItemClickListener{
            override fun onItemClick(parent: AdapterView<*>?, view: View?, position: Int, id: Long) {
                val intent1 = Intent(this@DirectionActivity, MapsActivity::class.java).apply {
                    putExtra("position", position)
                }
                RouteSave.pos = position
                // First initialize a list of UserInfoDTO.

                val initialUserInfoList: Routes = allRoute[position]
                // Create Gson object.
                val gson = Gson()
                // Get java object list json format string.
                val userInfoListJsonString = gson.toJson(initialUserInfoList)
                // Create SharedPreferences object.
                val ctx = applicationContext
                val sharedPreferences = ctx.getSharedPreferences(HISTORY, Context.MODE_PRIVATE)
                // Put the json format string to SharedPreferences object.
                val editor = sharedPreferences.edit()
                //var history = sharedPreferences.getString("History",null)
                //var historyRoutes = gson.fromJson(history,Route::class.java)
                //historyRoutes.routes.add(initialUserInfoList)
                //val userInfoListJsonString1 = gson.toJson(historyRoutes)
                //editor.putString("History",userInfoListJsonString1)


                editor.putString(id1.toString(), userInfoListJsonString)
                favouriteRoutes.add(id1,false)
                id1+=1
//            Toast.makeText(ctx, userInfoListJsonString, Toast.LENGTH_SHORT)
//                .show()
                editor.apply()
                //Popup a toast message in screen bottom.
                Toast.makeText(ctx, id1.toString() + " Route has been Saved to storage", Toast.LENGTH_SHORT)
                    .show()
                startActivity(intent1)
            }
        }


    }







    fun getDirectionURL(origin: String, dest: String, mode: Int): String {
        if (mode == 0) {
            return "https://maps.googleapis.com/maps/api/directions/json?origin=${origin}&destination=${dest}&mode=transit&transit_mode=bus|subway&alternatives=true&key=AIzaSyCkuHNW1JRQY9o-zLyCg65EuOws1vIP-RE"
        } else if (mode == 1) {
            return "https://maps.googleapis.com/maps/api/directions/json?origin=${origin}&destination=${dest}&mode=transit&transit_mode=bus&alternatives=true&key=AIzaSyCkuHNW1JRQY9o-zLyCg65EuOws1vIP-RE"
        } else if (mode == 2) {
            return "https://maps.googleapis.com/maps/api/directions/json?origin=${origin}&destination=${dest}&mode=transit&transit_mode=subway&alternatives=true&key=AIzaSyCkuHNW1JRQY9o-zLyCg65EuOws1vIP-RE"
        }
        return "error"
    }
    private val mOnNavigationItemSelectedListener = BottomNavigationView.OnNavigationItemSelectedListener { item ->
        when (item.itemId) {
            R.id.navigation_search -> {
                val intent1=Intent(this,MainActivity::class.java).apply(){}
                startActivity(intent1)

                return@OnNavigationItemSelectedListener true
            }
            R.id.navigation_current -> {
                val intent1= Intent(this,MapsActivity::class.java).apply(){}
                intent1.putExtra("position",RouteSave.pos)
                startActivity(intent1)
                return@OnNavigationItemSelectedListener true
            }
            R.id.navigation_hist -> {
                val intent1 = Intent(this, activity_hist::class.java).apply(){}
                startActivity(intent1)
                return@OnNavigationItemSelectedListener true
            }
            R.id.navigation_fav -> {

                return@OnNavigationItemSelectedListener true
            }
        }
        false
    }
    fun navigation(){
        val navigation = findViewById<BottomNavigationView>(R.id.navigation)

        navigation.getMenu().getItem(0).setChecked(true);
        navigation?.setOnNavigationItemSelectedListener OnNavigationItemSelectedListener@{ item: MenuItem ->
            //            item.isChecked = true
//            navigation.itemIconTintList = null
            when (item.itemId) {
                R.id.navigation_search -> {
//                    navigation.itemIconTintList = null;

                    if(clicked){
                        val a = Intent(this@DirectionActivity, MainActivity::class.java)
                        //setContentView(R.layout.activity_p1)
                        startActivity(a)
                    }
                    else{
                        val a = Intent(this@DirectionActivity, MainActivity::class.java)
                        //setContentView(R.layout.activity_p1)
                        startActivity(a)
                    }
                    return@OnNavigationItemSelectedListener true
                }

                R.id.navigation_current -> {
//                    navigation.itemIconTintList = null;
                    val a = Intent(this@DirectionActivity, MapsActivity::class.java)
                    a.putExtra("position",-1)
                    startActivity(a)
                    return@OnNavigationItemSelectedListener true
                }
                R.id.navigation_fav -> {
                    val c = Intent(this@DirectionActivity, activity_fav::class.java)
                    startActivity(c)
                    return@OnNavigationItemSelectedListener true
                }
                R.id.navigation_hist -> {
//                    navigation.itemIconTintList = null;
                    val c = Intent(this@DirectionActivity, activity_hist::class.java)
                    startActivity(c)
                    return@OnNavigationItemSelectedListener true
                }
            }
            false
        }
    }
    @Override
    fun onClick(v: View) {
        // TODO Auto-generated method stub
        clicked = true;
        //write your codes here
    }
}


