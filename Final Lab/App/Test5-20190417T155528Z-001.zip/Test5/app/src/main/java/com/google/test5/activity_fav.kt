package com.google.test5

import java.io.Serializable
import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.os.Bundle
import android.support.design.widget.BottomNavigationView
import android.support.v7.app.AppCompatActivity
import android.util.Log
import android.view.LayoutInflater
import android.view.MenuItem
import android.view.View
import android.view.ViewGroup
import android.widget.*
import com.google.gson.Gson
import kotlinx.android.synthetic.main.activity_direction.*
import kotlinx.android.synthetic.main.activity_main.*

class activity_fav : AppCompatActivity() {
    var clicked: Boolean = false
    private var listItems = ArrayList<Item>()  // Should contain all information needed about route
    private val FAVORITE = "favorite"
    var logic: control_activity_fav = control_activity_fav()
    lateinit var sharedPreferences : SharedPreferences

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        // enter code if (have fav)
        //setContentView(R.layout.activity_no_favourite)

        if(id_favorite == 0){
            setContentView(R.layout.activity_no_favorite)
            navigation()
        }
        else{
            setContentView(R.layout.activity_direction)
            navigation()
            //Favorite
//            var itemsAdapter = itemsAdapter(this, listItems)
//            listViewItems.adapter = itemsAdapter
//            listViewItems.onItemClickListener = AdapterView.OnItemClickListener { adapterView, view, position, id ->
//                Toast.makeText(this, "Click on " + listItems[position].title, Toast.LENGTH_SHORT).show()
//
//            }
            val ctx = applicationContext
            sharedPreferences =
                ctx.getSharedPreferences(FAVORITE, Context.MODE_PRIVATE)

            listItems = logic.getFavorites(ctx,sharedPreferences)
            var itemsAdapter = itemsAdapter(this, listItems)
            listView_1.adapter = itemsAdapter
            listView_1.onItemClickListener = AdapterView.OnItemClickListener { adapterView, view, position, id ->
                Toast.makeText(this, "Click on " + listItems[position].title, Toast.LENGTH_SHORT).show()
            }




            }
    }
    fun navigation(){
        val navigation = findViewById<BottomNavigationView>(R.id.navigation)

        navigation.getMenu().getItem(3).setChecked(true);
        navigation?.setOnNavigationItemSelectedListener OnNavigationItemSelectedListener@{ item: MenuItem ->
            //            item.isChecked = true
//            navigation.itemIconTintList = null
            when (item.itemId) {
                R.id.navigation_search -> {
//                    navigation.itemIconTintList = null;

                    if(clicked){
                        val a = Intent(this@activity_fav, MainActivity::class.java)
                        //setContentView(R.layout.activity_p1)
                        startActivity(a)
                    }
                    else{
                        val a = Intent(this@activity_fav, MainActivity::class.java)
                        //setContentView(R.layout.activity_p1)
                        startActivity(a)
                    }
                    return@OnNavigationItemSelectedListener true
                }

                R.id.navigation_current -> {
//                    navigation.itemIconTintList = null;
                    val a = Intent(this@activity_fav, MapsActivity::class.java)
                    a.putExtra("position",RouteSave.pos)
                    startActivity(a)
                    return@OnNavigationItemSelectedListener true
                }
                R.id.navigation_fav -> {

                    return@OnNavigationItemSelectedListener true
                }
                R.id.navigation_hist -> {
//                    navigation.itemIconTintList = null;
                    val c = Intent(this@activity_fav, activity_hist::class.java)
                    startActivity(c)
                    return@OnNavigationItemSelectedListener true
                }
            }
            false
        }
    }
        inner class itemsAdapter : BaseAdapter {

            private var itemsList = ArrayList<Item>()
            private var context: Context? = null

            constructor(context: Context, itemsList: ArrayList<Item>) : super() {
                this.itemsList = itemsList
                this.context = context
            }

            override fun getView(position: Int, convertView: View?, parent: ViewGroup?): View? {

                val view: View?
                val vh: ViewHolder

                if (convertView == null) {
                    view = layoutInflater.inflate(R.layout.activity_item, parent, false)
                    vh = ViewHolder(view)
                    view.tag = vh
                    Log.i("JSA", "set Tag for ViewHolder, position: " + position)
                } else {
                    view = convertView
                    vh = view.tag as ViewHolder
                }

                // Assigning information in view
                vh.tvTitle.text = itemsList[position].title
                val fav = context!!.getSharedPreferences("favorite",Context.MODE_PRIVATE)
                val favRoute : Routes = Gson().fromJson(fav.getString(position.toString(),""),Routes::class.java)
                var a : Int = 0
                for (i in 0..(favRoute.legs[0].steps.size-1)){
                    if (favRoute.legs[0].steps[i].travel_mode== "TRANSIT"){
                        if (favRoute.legs[0].steps[i].transit_details.line.vehicle.name == "Bus"){
                            if (a==0){
                                vh.iconOne.setImageResource(R.drawable.ic_bus)
                                vh.textOne.text = favRoute.legs[0].steps[i].transit_details.line.short_name
                                a++
                            }else if (a == 1){
                                vh.iconTwo.setImageResource(R.drawable.ic_bus)
                                vh.textTwo.text = favRoute.legs[0].steps[i].transit_details.line.short_name
                                a++
                            }else if (a == 2){
                                vh.iconThree.setImageResource(R.drawable.ic_bus)
                                vh.textThree.text = favRoute.legs[0].steps[i].transit_details.line.short_name
                                a++
                            }
                        }else if (favRoute.legs[0].steps[i].transit_details.line.vehicle.name == "Subway"){
                            if (a==0){
                                vh.iconOne.setImageResource(R.drawable.ic_mrt)
                                vh.textOne.text = favRoute.legs[0].steps[i].transit_details.line.name
                                a++
                            }else if (a == 1){
                                vh.iconTwo.setImageResource(R.drawable.ic_mrt)
                                vh.textTwo.text = favRoute.legs[0].steps[i].transit_details.line.name
                                a++
                            }else if (a == 2){
                                vh.iconThree.setImageResource(R.drawable.ic_mrt)
                                vh.textThree.text = favRoute.legs[0].steps[i].transit_details.line.name
                                a++
                            }
                        }
                    }
                }
                vh.tvDepTime.text = favRoute.legs[0].duration.text

                // Set listener to start route button
                vh.startRoute.setOnClickListener {
                    Toast.makeText(this@activity_fav, "You clicked me.", Toast.LENGTH_SHORT).show()

                    // Call on new activity
                    val intent = Intent(this@activity_fav, MapsActivity::class.java)
                    intent.putExtra("position",0 )
                    RouteSave.routes[0]= Gson().fromJson(sharedPreferences.getString(position.toString(),""),Routes::class.java)
                    startActivity(intent)
                }


                // Handle click on stars
                vh.starFilled.setOnClickListener {
                    Toast.makeText(this@activity_fav, "Deleted route from favorites.", Toast.LENGTH_SHORT).show()
                    favouriteRoutes[favId[position]] = false
                    favId.removeAt(position)
                    itemsList.removeAt(position)
                    var x = position
                    val ctx = applicationContext
                    logic.delFavorite(x,ctx)
                    //deleteFavorite()
                    this.notifyDataSetChanged()
                }
                // Set listener to start route button
                /*
                vh.startRoute.setOnClickListener {
                    Toast.makeText(this@activity_fav, "You clicked me.", Toast.LENGTH_SHORT).show()

                    // Call on new activity
                    val intent = Intent(this@activity_fav, MapsActivity::class.java)
                    //intent.putExtra("selectedRoute", itemsList[position] as Serializable) // Pass object to new activity
                    startActivity(intent)
                }*/


                // Handle click on stars
                /*
                vh.starFilled.setOnClickListener {
                Toast.makeText(this@MainActivity, "Deleted route from favorites.", Toast.LENGTH_SHORT).show()
                itemsList.removeAt(position)
                vh.starFilled.visibility = View.GONE
                vh.starEmpty.visibility = View.VISIBLE
                }*/

                return view
            }

            override fun getItem(position: Int): Any {
                return itemsList[position]
            }

            override fun getItemId(position: Int): Long {
                return position.toLong()
            }

            override fun getCount(): Int {
                return itemsList.size
            }
        }


        private class ViewHolder(view: View?) {
            val tvTitle: TextView
            val iconOne: ImageView
            val textOne: TextView
            val iconTwo: ImageView
            val textTwo: TextView
            val iconThree: ImageView
            val textThree: TextView
            val tvDepTime: TextView
            val startRoute: ImageButton
            val starEmpty: ImageButton
            val starFilled: ImageButton


            init {
                this.tvTitle = view?.findViewById(R.id.tvTitle) as TextView
                this.iconOne = view?.findViewById(R.id.iconOne) as ImageView
                this.textOne = view?.findViewById(R.id.textOne) as TextView
                this.iconTwo = view?.findViewById(R.id.iconTwo) as ImageView
                this.textTwo = view?.findViewById(R.id.textTwo) as TextView
                this.iconThree = view?.findViewById(R.id.iconThree) as ImageView
                this.textThree = view?.findViewById(R.id.textThree) as TextView
                this.tvDepTime = view?.findViewById(R.id.tvDepartTime) as TextView
                this.startRoute = view?.findViewById(R.id.startRouteArrow) as ImageButton
                this.starEmpty = view?.findViewById(R.id.starEmpty) as ImageButton
                this.starFilled = view?.findViewById(R.id.starFilled) as ImageButton
            }

            //  if you target API 26, you should change to:
//        init {
//            this.tvTitle = view?.findViewById<TextView>(R.id.tvTitle) as TextView
//            this.tvContent = view?.findViewById<TextView>(R.id.tvContent) as TextView
//        }
        }
    @Override
    fun onClick(v: View) {
        // TODO Auto-generated method stub
        clicked = true;
        //write your codes here
    }
}